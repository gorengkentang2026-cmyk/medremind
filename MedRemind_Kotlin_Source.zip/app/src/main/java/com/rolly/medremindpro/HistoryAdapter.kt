package com.rolly.medremindpro

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class HistoryAdapter(
    private val items: List<HistoryItem>,
    private val userMap: Map<Int, String> = emptyMap()
) : RecyclerView.Adapter<HistoryAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_history, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvName.text = item.nama
        holder.tvTime.text = item.waktu

        val userName = userMap[item.userId] ?: "Pengguna"
        holder.tvDetails.text = "👤 $userName • Sesi ${item.sesi} • Dosis: ${item.dosis} • Sisa: ${item.sisaStok}"
    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvHistName)
        val tvTime: TextView = view.findViewById(R.id.tvHistTime)
        val tvDetails: TextView = view.findViewById(R.id.tvHistDetails)
    }
}
