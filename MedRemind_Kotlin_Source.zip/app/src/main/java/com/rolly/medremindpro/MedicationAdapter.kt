package com.rolly.medremindpro

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton

/**
 * Adapter RecyclerView Multifungsi untuk MedRemind Pro
 * Mendukung mode 'Jadwal Hari Ini' dan mode 'Semua Obat'
 * Release by Rolly
 */
class MedicationAdapter(
    private val context: Context,
    private val repo: MedicationRepository,
    private val onTakeScheduleClick: (TodayScheduleItem) -> Unit,
    private val onRestockClick: (Medication) -> Unit,
    private val onEditClick: (Medication) -> Unit,
    private val onDeleteClick: (Medication) -> Unit
) : RecyclerView.Adapter<MedicationAdapter.ViewHolder>() {

    private var isTodayView = true
    private val todayItems = mutableListOf<TodayScheduleItem>()
    private val allMeds = mutableListOf<Medication>()

    fun setTodayScheduleData(items: List<TodayScheduleItem>) {
        isTodayView = true
        todayItems.clear()
        todayItems.addAll(items)
        notifyDataSetChanged()
    }

    fun setAllMedicationsData(items: List<Medication>) {
        isTodayView = false
        allMeds.clear()
        allMeds.addAll(items)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_medication, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = if (isTodayView) todayItems.size else allMeds.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        if (isTodayView) {
            holder.bindToday(todayItems[position])
        } else {
            holder.bindMedication(allMeds[position])
        }
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvName: TextView = itemView.findViewById(R.id.tvItemName)
        private val tvTimeBadge: TextView = itemView.findViewById(R.id.tvItemTimeBadge)
        private val tvDetails: TextView = itemView.findViewById(R.id.tvItemDetails)
        private val tvStock: TextView = itemView.findViewById(R.id.tvItemStock)
        private val tvNote: TextView = itemView.findViewById(R.id.tvItemNote)
        private val btnTake: MaterialButton = itemView.findViewById(R.id.btnItemTake)
        private val btnRestock: MaterialButton = itemView.findViewById(R.id.btnItemRestock)
        private val btnEdit: MaterialButton = itemView.findViewById(R.id.btnItemEdit)
        private val btnDelete: MaterialButton = itemView.findViewById(R.id.btnItemDelete)

        fun bindToday(item: TodayScheduleItem) {
            val med = item.med
            tvName.text = med.nama
            tvTimeBadge.text = "${item.sesiNama} • ${item.jam} WIB"
            tvDetails.text = "Dosis: ${med.dosis} • ${med.aturan}"

            tvStock.text = "📦 Sisa: ${med.stok} ${med.satuan}"
            if (med.stok <= 0) {
                tvStock.text = "❌ Habis (0 ${med.satuan})"
                tvStock.setTextColor(ContextCompat.getColor(context, R.color.danger))
            } else if (med.stok <= 5) {
                tvStock.text = "⚠ ${med.stok} ${med.satuan} (Menipis)"
                tvStock.setTextColor(ContextCompat.getColor(context, R.color.warning))
            } else {
                tvStock.setTextColor(ContextCompat.getColor(context, R.color.success))
            }

            tvNote.text = if (med.catatan.isNotBlank() && med.catatan != "-") "Ket: ${med.catatan}" else ""

            btnRestock.visibility = View.GONE
            btnEdit.visibility = View.GONE
            btnDelete.visibility = View.GONE
            btnTake.visibility = View.VISIBLE

            if (item.isDone) {
                btnTake.text = "✅ Sudah Diminum"
                btnTake.setBackgroundColor(ContextCompat.getColor(context, R.color.card_stroke))
                btnTake.setTextColor(ContextCompat.getColor(context, R.color.text_muted))
                btnTake.isEnabled = false
            } else {
                btnTake.text = "✔ Minum Sekarang"
                btnTake.setBackgroundColor(ContextCompat.getColor(context, R.color.success))
                btnTake.setTextColor(Color.WHITE)
                btnTake.isEnabled = true
                btnTake.setOnClickListener { onTakeScheduleClick(item) }
            }
        }

        fun bindMedication(med: Medication) {
            tvName.text = med.nama

            // Gabungkan info sesi
            val sessionParts = mutableListOf<String>()
            if (med.sesiPagiAktif) sessionParts.add("🌅 ${med.jamPagi}")
            if (med.sesiSiangAktif) sessionParts.add("☀ ${med.jamSiang}")
            if (med.sesiSoreAktif) sessionParts.add("🌙 ${med.jamSore}")
            tvTimeBadge.text = if (sessionParts.isNotEmpty()) sessionParts.joinToString(" | ") else "Tidak ada sesi"

            val hariInfo = if (med.hariTipe == "Setiap Hari") "Setiap Hari" else med.hariAktif.joinToString(", ") { it.take(3) }
            tvDetails.text = "Dosis: ${med.dosis} • ${med.aturan} • 📅 $hariInfo"

            tvStock.text = "📦 Stok: ${med.stok} ${med.satuan}"
            if (med.stok <= 0) {
                tvStock.text = "❌ Stok Habis!"
                tvStock.setTextColor(ContextCompat.getColor(context, R.color.danger))
            } else if (med.stok <= 5) {
                tvStock.text = "⚠ Sisa: ${med.stok} ${med.satuan} (Segera Restock)"
                tvStock.setTextColor(ContextCompat.getColor(context, R.color.warning))
            } else {
                tvStock.setTextColor(ContextCompat.getColor(context, R.color.success))
            }

            tvNote.text = if (med.catatan.isNotBlank() && med.catatan != "-") "Ket: ${med.catatan}" else ""

            btnTake.visibility = View.GONE
            btnRestock.visibility = View.VISIBLE
            btnEdit.visibility = View.VISIBLE
            btnDelete.visibility = View.VISIBLE

            btnRestock.setOnClickListener { onRestockClick(med) }
            btnEdit.setOnClickListener { onEditClick(med) }
            btnDelete.setOnClickListener { onDeleteClick(med) }
        }
    }
}
