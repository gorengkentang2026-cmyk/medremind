package com.rolly.medremindpro

import android.Manifest
import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import com.google.android.material.tabs.TabLayout
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Layar Utama Dashboard MedRemind Pro
 * Lengkap dengan Multi-User, Nada Dering Kustom, dan Tema Gelap/Terang
 * Release by Rolly
 */
class MainActivity : AppCompatActivity() {

    private lateinit var repo: MedicationRepository
    private lateinit var adapter: MedicationAdapter

    private lateinit var tvGreeting: TextView
    private lateinit var tvDigitalClock: TextView
    private lateinit var tvMetricTotal: TextView
    private lateinit var tvMetricTaken: TextView
    private lateinit var tvMetricPending: TextView
    private lateinit var tvMetricLowStock: TextView
    private lateinit var tvNextSchedule: TextView

    private lateinit var btnToggleTheme: MaterialButton
    private lateinit var spUserProfile: Spinner
    private lateinit var btnManageUsers: MaterialButton
    private lateinit var btnNavGoogle: MaterialButton
    private lateinit var btnGoogleBadge: MaterialButton

    private lateinit var tabLayout: TabLayout
    private lateinit var rvMedications: RecyclerView
    private lateinit var tvEmptyState: TextView
    private lateinit var fabAdd: ExtendedFloatingActionButton

    private var previewPlayer: MediaPlayer? = null

    private val clockHandler = Handler(Looper.getMainLooper())
    private val clockRunnable = object : Runnable {
        override fun run() {
            updateClockAndGreeting()
            clockHandler.postDelayed(this, 1000)
        }
    }

    // Peluncur Google Sign-In Resmi
    private val googleSignInLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        handleGoogleSignInResult(task)
    }

    // Pemilih Ringtone Kustom dari Penyimpanan HP / Sistem Android
    private val ringtonePickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uri: Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            }

            if (uri != null) {
                val ringtone = RingtoneManager.getRingtone(this, uri)
                val title = ringtone?.getTitle(this) ?: "Nada Kustom"
                repo.setRingtone(uri, title)
                Toast.makeText(this, "🎵 Nada dering dipilih: $title", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        repo = MedicationRepository(this)

        // Terapkan Tema Gelap / Terang sebelum super.onCreate
        if (repo.isDarkMode()) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupUserSpinner()
        requestPermissionsIfNeeded()

        // Pasang seluruh jadwal alarm saat aplikasi dibuka
        AlarmScheduler.scheduleAll(this)

        refreshDashboard()
    }

    override fun onResume() {
        super.onResume()
        clockHandler.post(clockRunnable)
        refreshDashboard()
    }

    override fun onPause() {
        super.onPause()
        clockHandler.removeCallbacks(clockRunnable)
        stopPreviewPlayer()
    }

    private fun initViews() {
        tvGreeting = findViewById(R.id.tvGreeting)
        tvDigitalClock = findViewById(R.id.tvDigitalClock)
        tvMetricTotal = findViewById(R.id.tvMetricTotal)
        tvMetricTaken = findViewById(R.id.tvMetricTaken)
        tvMetricPending = findViewById(R.id.tvMetricPending)
        tvMetricLowStock = findViewById(R.id.tvMetricLowStock)
        tvNextSchedule = findViewById(R.id.tvNextSchedule)

        btnToggleTheme = findViewById(R.id.btnToggleTheme)
        spUserProfile = findViewById(R.id.spUserProfile)
        btnManageUsers = findViewById(R.id.btnManageUsers)
        btnNavGoogle = findViewById(R.id.btnNavGoogle)
        btnGoogleBadge = findViewById(R.id.btnGoogleBadge)

        tabLayout = findViewById(R.id.tabLayoutMain)
        rvMedications = findViewById(R.id.rvMedications)
        tvEmptyState = findViewById(R.id.tvEmptyState)
        fabAdd = findViewById(R.id.fabAddMedication)

        // Set icon tombol tema
        btnToggleTheme.text = if (repo.isDarkMode()) "🌙" else "☀️"
        btnToggleTheme.setOnClickListener {
            toggleTheme()
        }

        // Tombol Nada Dering Kustom
        findViewById<MaterialButton>(R.id.btnNavRingtone).setOnClickListener {
            showRingtoneDialog()
        }

        // Tombol Kelola Profil Multi-User
        btnManageUsers.setOnClickListener {
            showUserProfileDialog()
        }

        // Tombol Sambungkan Akun Google
        btnNavGoogle.setOnClickListener {
            showGoogleAccountDialog()
        }
        btnGoogleBadge.setOnClickListener {
            showGoogleAccountDialog()
        }

        findViewById<MaterialButton>(R.id.btnNavWhatsApp).setOnClickListener {
            showWhatsAppDialog()
        }

        findViewById<MaterialButton>(R.id.btnNavHistory).setOnClickListener {
            showHistoryDialog()
        }

        findViewById<MaterialButton>(R.id.btnNavTestAlarm).setOnClickListener {
            testAlarmSound()
        }

        fabAdd.setOnClickListener {
            showAddEditDialog(null)
        }

        adapter = MedicationAdapter(
            context = this,
            repo = repo,
            onTakeScheduleClick = { item ->
                repo.markTaken(item.med.id, item.sesiKey, item.sesiNama)
                Toast.makeText(this, "✔ Berhasil minum ${item.med.nama} (${item.sesiNama})!", Toast.LENGTH_SHORT).show()
                refreshDashboard()
            },
            onRestockClick = { med ->
                repo.restock(med.id, 10)
                Toast.makeText(this, "📦 +10 ${med.satuan} stok ditambahkan untuk ${med.nama}!", Toast.LENGTH_SHORT).show()
                refreshDashboard()
            },
            onEditClick = { med ->
                showAddEditDialog(med)
            },
            onDeleteClick = { med ->
                MaterialAlertDialogBuilder(this)
                    .setTitle("Hapus Obat")
                    .setMessage("Yakin ingin menghapus '${med.nama}' beserta seluruh jadwalnya?")
                    .setPositiveButton("Hapus") { _, _ ->
                        AlarmScheduler.cancelMedication(this, med.id)
                        repo.deleteMedication(med.id)
                        Toast.makeText(this, "Obat '${med.nama}' berhasil dihapus", Toast.LENGTH_SHORT).show()
                        refreshDashboard()
                    }
                    .setNegativeButton("Batal", null)
                    .show()
            }
        )

        rvMedications.layoutManager = LinearLayoutManager(this)
        rvMedications.adapter = adapter

        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                loadTabData()
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun toggleTheme() {
        val newDark = !repo.isDarkMode()
        repo.setDarkMode(newDark)
        if (newDark) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
    }

    private fun setupUserSpinner() {
        val users = repo.getAllUsers()
        val userNames = mutableListOf("Semua Profil (Gabungan)")
        userNames.addAll(users.map { "👤 ${it.nama} (${it.hubungan})" })

        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, userNames)
        spUserProfile.adapter = spinnerAdapter

        val activeId = repo.getActiveUserId()
        if (activeId == 0) {
            spUserProfile.setSelection(0)
        } else {
            val idx = users.indexOfFirst { it.id == activeId }
            if (idx != -1) {
                spUserProfile.setSelection(idx + 1)
            }
        }

        spUserProfile.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position == 0) {
                    repo.setActiveUserId(0)
                } else {
                    val selectedUser = users.getOrNull(position - 1)
                    if (selectedUser != null) {
                        repo.setActiveUserId(selectedUser.id)
                    }
                }
                refreshDashboard()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun updateClockAndGreeting() {
        val now = Calendar.getInstance()
        val hour = now.get(Calendar.HOUR_OF_DAY)
        val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        tvDigitalClock.text = timeStr

        val activeUser = repo.getActiveUser()
        val userName = if (repo.getActiveUserId() != 0) " ${activeUser.nama}" else ""

        val greeting = when (hour) {
            in 4..10 -> "Selamat Pagi$userName 🌅"
            in 11..14 -> "Selamat Siang$userName ☀"
            in 15..17 -> "Selamat Sore$userName 🌤"
            else -> "Selamat Malam$userName 🌙"
        }
        tvGreeting.text = greeting
    }

    private fun refreshDashboard() {
        val metrics = repo.getMetrics()
        tvMetricTotal.text = metrics.totalObat.toString()
        tvMetricTaken.text = metrics.sudahDiminum.toString()
        tvMetricPending.text = metrics.menunggu.toString()
        tvMetricLowStock.text = metrics.stokMenipis.toString()

        tvNextSchedule.text = "⏰ Jadwal Berikut: ${repo.getNextScheduleInfo()}"

        updateGoogleStatusUi()
        loadTabData()
    }

    private fun updateGoogleStatusUi() {
        val googleAcc = repo.getGoogleAccount()
        if (googleAcc.isConnected) {
            val shortEmail = googleAcc.email.substringBefore('@')
            btnGoogleBadge.text = "✅ $shortEmail"
            btnGoogleBadge.setTextColor(ContextCompat.getColor(this, R.color.success))
            btnNavGoogle.text = "G✓"
            btnNavGoogle.strokeColor = ContextCompat.getColorStateList(this, R.color.success)
        } else {
            btnGoogleBadge.text = "🌐 Google"
            btnGoogleBadge.setTextColor(ContextCompat.getColor(this, R.color.google_blue))
            btnNavGoogle.text = "🌐"
            btnNavGoogle.strokeColor = ContextCompat.getColorStateList(this, R.color.google_blue)
        }
    }

    private fun loadTabData() {
        val isTodayTab = tabLayout.selectedTabPosition == 0
        if (isTodayTab) {
            val todayList = repo.getTodaySchedule()
            adapter.setTodayScheduleData(todayList)
            tvEmptyState.text = "Tidak ada jadwal minum obat untuk hari ini (${repo.getHariIni()})."
            tvEmptyState.visibility = if (todayList.isEmpty()) View.VISIBLE else View.GONE
        } else {
            val allList = repo.getMedicationsForActiveUser()
            adapter.setAllMedicationsData(allList)
            tvEmptyState.text = "Belum ada daftar obat tersimpan.\nTekan tombol ➕ Tambah Obat di bawah."
            tvEmptyState.visibility = if (allList.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    // ─── DIALOG MULTI-USER / PROFIL ─────────────────────────────────
    private fun showUserProfileDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_user_profile, null)
        val etUserName = view.findViewById<EditText>(R.id.etUserName)
        val etUserRole = view.findViewById<EditText>(R.id.etUserRole)
        val btnAddSubmit = view.findViewById<MaterialButton>(R.id.btnAddUserSubmit)
        val layoutUserList = view.findViewById<LinearLayout>(R.id.layoutUserList)
        val btnClose = view.findViewById<MaterialButton>(R.id.btnUserClose)

        val dialog = AlertDialog.Builder(this)
            .setView(view)
            .create()

        fun refreshList() {
            layoutUserList.removeAllViews()
            val users = repo.getAllUsers()
            for (u in users) {
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(0, 10, 0, 10)
                }
                val tv = TextView(this).apply {
                    val gEmailInfo = if (!u.googleEmail.isNullOrEmpty()) "\n   🌐 Google: ${u.googleEmail}" else ""
                    text = "👤 ${u.nama} (${u.hubungan})$gEmailInfo"
                    setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_primary))
                    textSize = 14f
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                row.addView(tv)

                if (users.size > 1) {
                    val btnDel = MaterialButton(this, null, com.google.android.material.R.attr.borderlessButtonStyle).apply {
                        text = "🗑 Hapus"
                        setTextColor(ContextCompat.getColor(this@MainActivity, R.color.danger))
                        textSize = 11f
                        setOnClickListener {
                            repo.deleteUser(u.id)
                            refreshList()
                            setupUserSpinner()
                            refreshDashboard()
                            Toast.makeText(this@MainActivity, "Profil '${u.nama}' dihapus", Toast.LENGTH_SHORT).show()
                        }
                    }
                    row.addView(btnDel)
                }
                layoutUserList.addView(row)
            }
        }
        refreshList()

        view.findViewById<MaterialButton?>(R.id.btnOpenGoogleFromUser)?.setOnClickListener {
            dialog.dismiss()
            showGoogleAccountDialog()
        }

        btnAddSubmit.setOnClickListener {
            val name = etUserName.text.toString().trim()
            val role = etUserRole.text.toString().trim().ifEmpty { "Keluarga" }
            if (name.isEmpty()) {
                etUserName.error = "Nama profil wajib diisi!"
                return@setOnClickListener
            }
            repo.addUser(name, role)
            etUserName.setText("")
            refreshList()
            setupUserSpinner()
            refreshDashboard()
            Toast.makeText(this, "✅ Profil '$name' berhasil ditambahkan!", Toast.LENGTH_SHORT).show()
        }

        btnClose.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    // ─── DIALOG NADA DERING KUSTOM ──────────────────────────────────
    private fun showRingtoneDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_ringtone, null)
        val rgOptions = view.findViewById<RadioGroup>(R.id.rgRingtoneOptions)
        val rbDefault = view.findViewById<RadioButton>(R.id.rbDefaultAlarm)
        val rbNotification = view.findViewById<RadioButton>(R.id.rbRingtoneNotification)
        val rbCustom = view.findViewById<RadioButton>(R.id.rbCustomFile)
        val tvSelected = view.findViewById<TextView>(R.id.tvSelectedRingtoneName)
        val btnPreview = view.findViewById<MaterialButton>(R.id.btnPreviewRingtone)
        val btnSave = view.findViewById<MaterialButton>(R.id.btnSaveRingtone)
        val btnClose = view.findViewById<MaterialButton>(R.id.btnCloseRingtone)

        var chosenUri: Uri? = repo.getRingtoneUri()
        var chosenName: String = repo.getRingtoneName()
        tvSelected.text = "Nada saat ini: $chosenName"

        val dialog = AlertDialog.Builder(this)
            .setView(view)
            .create()

        rbDefault.setOnClickListener {
            chosenUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            chosenName = "Alarm Bawaan Android"
            tvSelected.text = "Nada dipilih: $chosenName"
        }

        rbNotification.setOnClickListener {
            chosenUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            chosenName = "Nada Notifikasi Standar"
            tvSelected.text = "Nada dipilih: $chosenName"
        }

        rbCustom.setOnClickListener {
            // Buka pemilih nada dering bawaan Android / Audio Picker
            val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM or RingtoneManager.TYPE_RINGTONE)
                putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Pilih Nada Dering Kustom")
                putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, chosenUri)
                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
            }
            ringtonePickerLauncher.launch(intent)
            dialog.dismiss()
        }

        btnPreview.setOnClickListener {
            stopPreviewPlayer()
            try {
                previewPlayer = MediaPlayer().apply {
                    setDataSource(this@MainActivity, chosenUri ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                    setOnCompletionListener { stopPreviewPlayer() }
                    prepare()
                    start()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Tidak dapat memutar nada dering ini", Toast.LENGTH_SHORT).show()
            }
        }

        btnSave.setOnClickListener {
            stopPreviewPlayer()
            repo.setRingtone(chosenUri, chosenName)
            Toast.makeText(this, "Nada dering tersimpan: $chosenName", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }

        btnClose.setOnClickListener {
            stopPreviewPlayer()
            dialog.dismiss()
        }

        dialog.setOnDismissListener { stopPreviewPlayer() }
        dialog.show()
    }

    private fun stopPreviewPlayer() {
        try {
            previewPlayer?.stop()
            previewPlayer?.release()
            previewPlayer = null
        } catch (e: Exception) {}
    }

    // ─── DIALOG TAMBAH / EDIT OBAT ──────────────────────────────────
    private fun showAddEditDialog(medToEdit: Medication?) {
        val view = layoutInflater.inflate(R.layout.dialog_add_edit, null)
        val tvTitle = view.findViewById<TextView>(R.id.tvDialogTitle)
        val spMedUser = view.findViewById<Spinner>(R.id.spMedUser)
        val etName = view.findViewById<EditText>(R.id.etMedName)
        val etDosis = view.findViewById<EditText>(R.id.etMedDosis)
        val spSatuan = view.findViewById<Spinner>(R.id.spMedSatuan)
        val etStock = view.findViewById<EditText>(R.id.etMedStock)
        val etKurangi = view.findViewById<EditText>(R.id.etMedKurangi)
        val spRule = view.findViewById<Spinner>(R.id.spMedRule)
        val etNote = view.findViewById<EditText>(R.id.etMedNote)

        val cbPagi = view.findViewById<CheckBox>(R.id.cbSesiPagi)
        val etJamPagi = view.findViewById<EditText>(R.id.etJamPagi)
        val cbSiang = view.findViewById<CheckBox>(R.id.cbSesiSiang)
        val etJamSiang = view.findViewById<EditText>(R.id.etJamSiang)
        val cbSore = view.findViewById<CheckBox>(R.id.cbSesiSore)
        val etJamSore = view.findViewById<EditText>(R.id.etJamSore)

        val spHariTipe = view.findViewById<Spinner>(R.id.spHariTipe)
        val layoutHariChecks = view.findViewById<LinearLayout>(R.id.layoutHariChecks)

        val cbSenin = view.findViewById<CheckBox>(R.id.cbHariSenin)
        val cbSelasa = view.findViewById<CheckBox>(R.id.cbHariSelasa)
        val cbRabu = view.findViewById<CheckBox>(R.id.cbHariRabu)
        val cbKamis = view.findViewById<CheckBox>(R.id.cbHariKamis)
        val cbJumat = view.findViewById<CheckBox>(R.id.cbHariJumat)
        val cbSabtu = view.findViewById<CheckBox>(R.id.cbHariSabtu)
        val cbMinggu = view.findViewById<CheckBox>(R.id.cbHariMinggu)

        val btnCancel = view.findViewById<MaterialButton>(R.id.btnDialogCancel)
        val btnSave = view.findViewById<MaterialButton>(R.id.btnDialogSave)

        // Setup Spinner Multi-User
        val users = repo.getAllUsers()
        val userNames = users.map { "👤 ${it.nama} (${it.hubungan})" }
        val userAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, userNames)
        spMedUser.adapter = userAdapter

        val activeUserId = repo.getActiveUserId()
        val defaultUserIdx = users.indexOfFirst { it.id == (medToEdit?.userId ?: activeUserId) }
        if (defaultUserIdx >= 0) spMedUser.setSelection(defaultUserIdx)

        // Setup Spinners
        val satuanAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, MedicationRepository.DAFTAR_SATUAN)
        spSatuan.adapter = satuanAdapter

        val ruleAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, MedicationRepository.DAFTAR_ATURAN)
        spRule.adapter = ruleAdapter

        val hariTipeList = listOf("Setiap Hari", "Pilih Hari Tertentu")
        val hariTipeAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, hariTipeList)
        spHariTipe.adapter = hariTipeAdapter

        spHariTipe.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, position: Int, id: Long) {
                layoutHariChecks.visibility = if (position == 1) View.VISIBLE else View.GONE
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // Setup TimePickers
        fun setupTimePicker(editText: EditText) {
            editText.setOnClickListener {
                val current = editText.text.toString().split(":")
                val h = current.getOrNull(0)?.toIntOrNull() ?: 8
                val m = current.getOrNull(1)?.toIntOrNull() ?: 0
                TimePickerDialog(this, { _, selectedH, selectedM ->
                    editText.setText(String.format(Locale.getDefault(), "%02d:%02d", selectedH, selectedM))
                }, h, m, true).show()
            }
        }
        setupTimePicker(etJamPagi)
        setupTimePicker(etJamSiang)
        setupTimePicker(etJamSore)

        if (medToEdit != null) {
            tvTitle.text = "Edit Jadwal Obat"
            etName.setText(medToEdit.nama)
            etDosis.setText(medToEdit.dosis)
            val satIndex = MedicationRepository.DAFTAR_SATUAN.indexOf(medToEdit.satuan)
            if (satIndex >= 0) spSatuan.setSelection(satIndex)
            etStock.setText(medToEdit.stok.toString())
            etKurangi.setText(medToEdit.kurangiPerMinum.toString())
            val ruleIndex = MedicationRepository.DAFTAR_ATURAN.indexOf(medToEdit.aturan)
            if (ruleIndex >= 0) spRule.setSelection(ruleIndex)
            etNote.setText(medToEdit.catatan)

            cbPagi.isChecked = medToEdit.sesiPagiAktif
            etJamPagi.setText(medToEdit.jamPagi)
            cbSiang.isChecked = medToEdit.sesiSiangAktif
            etJamSiang.setText(medToEdit.jamSiang)
            cbSore.isChecked = medToEdit.sesiSoreAktif
            etJamSore.setText(medToEdit.jamSore)

            if (medToEdit.hariTipe == "Pilih Hari Tertentu") {
                spHariTipe.setSelection(1)
                layoutHariChecks.visibility = View.VISIBLE
                val ha = medToEdit.hariAktif
                cbSenin.isChecked = ha.contains("Senin")
                cbSelasa.isChecked = ha.contains("Selasa")
                cbRabu.isChecked = ha.contains("Rabu")
                cbKamis.isChecked = ha.contains("Kamis")
                cbJumat.isChecked = ha.contains("Jumat")
                cbSabtu.isChecked = ha.contains("Sabtu")
                cbMinggu.isChecked = ha.contains("Minggu")
            } else {
                spHariTipe.setSelection(0)
                layoutHariChecks.visibility = View.GONE
            }
        }

        val dialog = AlertDialog.Builder(this)
            .setView(view)
            .create()

        btnCancel.setOnClickListener { dialog.dismiss() }

        btnSave.setOnClickListener {
            val name = etName.text.toString().trim()
            if (name.isEmpty()) {
                etName.error = "Nama obat wajib diisi!"
                return@setOnClickListener
            }

            val pagiAktif = cbPagi.isChecked
            val siangAktif = cbSiang.isChecked
            val soreAktif = cbSore.isChecked

            if (!pagiAktif && !siangAktif && !soreAktif) {
                Toast.makeText(this, "Aktifkan minimal 1 sesi waktu minum obat!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val hariTipe = spHariTipe.selectedItem.toString()
            val hariAktifList = mutableListOf<String>()
            if (hariTipe == "Pilih Hari Tertentu") {
                if (cbSenin.isChecked) hariAktifList.add("Senin")
                if (cbSelasa.isChecked) hariAktifList.add("Selasa")
                if (cbRabu.isChecked) hariAktifList.add("Rabu")
                if (cbKamis.isChecked) hariAktifList.add("Kamis")
                if (cbJumat.isChecked) hariAktifList.add("Jumat")
                if (cbSabtu.isChecked) hariAktifList.add("Sabtu")
                if (cbMinggu.isChecked) hariAktifList.add("Minggu")

                if (hariAktifList.isEmpty()) {
                    Toast.makeText(this, "Pilih minimal 1 hari aktif!", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
            } else {
                hariAktifList.addAll(MedicationRepository.DAFTAR_HARI)
            }

            val selectedUserIdx = spMedUser.selectedItemPosition
            val assignedUserId = users.getOrNull(selectedUserIdx)?.id ?: 1

            val stock = etStock.text.toString().toIntOrNull() ?: 30
            val kurangi = etKurangi.text.toString().toIntOrNull() ?: 1
            val dosis = etDosis.text.toString().trim().ifEmpty { "1 Tablet" }
            val satuan = spSatuan.selectedItem.toString()
            val rule = spRule.selectedItem.toString()
            val note = etNote.text.toString().trim().ifEmpty { "-" }

            val med = medToEdit ?: Medication()
            med.userId = assignedUserId
            med.nama = name
            med.dosis = dosis
            med.stok = stock
            med.satuan = satuan
            med.kurangiPerMinum = kurangi
            med.aturan = rule
            med.catatan = note
            med.hariTipe = hariTipe
            med.hariAktif = hariAktifList

            med.sesiPagiAktif = pagiAktif
            med.jamPagi = etJamPagi.text.toString().trim().ifEmpty { "07:00" }

            med.sesiSiangAktif = siangAktif
            med.jamSiang = etJamSiang.text.toString().trim().ifEmpty { "13:00" }

            med.sesiSoreAktif = soreAktif
            med.jamSore = etJamSore.text.toString().trim().ifEmpty { "19:00" }

            med.jam = if (pagiAktif) med.jamPagi else if (siangAktif) med.jamSiang else med.jamSore

            val savedId = repo.addOrUpdateMedication(med)
            med.id = savedId

            AlarmScheduler.scheduleMedication(this, med)

            dialog.dismiss()
            Toast.makeText(this, "✅ Jadwal obat '${med.nama}' berhasil disimpan!", Toast.LENGTH_SHORT).show()
            refreshDashboard()
        }

        dialog.show()
    }

    private fun showWhatsAppDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_whatsapp, null)
        val cbEnabled = view.findViewById<CheckBox>(R.id.cbWaEnabled)
        val etPhone = view.findViewById<EditText>(R.id.etWaNumber)
        val etApiKey = view.findViewById<EditText>(R.id.etWaApiKey)
        val btnCancel = view.findViewById<MaterialButton>(R.id.btnWaCancel)
        val btnTest = view.findViewById<MaterialButton>(R.id.btnWaTest)
        val btnSave = view.findViewById<MaterialButton>(R.id.btnWaSave)

        val (savedPhone, savedApiKey, isEnabled) = WhatsAppNotifier.getConfig(this)
        cbEnabled.isChecked = isEnabled
        etPhone.setText(savedPhone)
        etApiKey.setText(savedApiKey)

        val dialog = AlertDialog.Builder(this)
            .setView(view)
            .create()

        btnCancel.setOnClickListener { dialog.dismiss() }

        btnTest.setOnClickListener {
            val phone = etPhone.text.toString().trim()
            val apiKey = etApiKey.text.toString().trim()
            if (phone.isEmpty() || apiKey.isEmpty()) {
                Toast.makeText(this, "Isi nomor WhatsApp dan API Key terlebih dahulu!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            Toast.makeText(this, "Mengirim pesan uji coba ke WhatsApp...", Toast.LENGTH_SHORT).show()
            WhatsAppNotifier.sendMessageAsync(phone, apiKey, "🔔 *Uji Coba MedRemind Pro*\nKoneksi WhatsApp berhasil terhubung!") { success ->
                runOnUiThread {
                    if (success) {
                        Toast.makeText(this, "✔ Pesan WhatsApp berhasil terkirim!", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this, "❌ Gagal kirim WhatsApp. Periksa nomor & API Key.", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }

        btnSave.setOnClickListener {
            val phone = etPhone.text.toString().trim()
            val apiKey = etApiKey.text.toString().trim()
            val enabled = cbEnabled.isChecked

            WhatsAppNotifier.saveConfig(this, phone, apiKey, enabled)
            dialog.dismiss()
            Toast.makeText(this, "Pengaturan WhatsApp disimpan", Toast.LENGTH_SHORT).show()
        }

        dialog.show()
    }

    private fun showHistoryDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_history, null)
        val rvHistory = view.findViewById<RecyclerView>(R.id.rvHistoryList)
        val btnClear = view.findViewById<MaterialButton>(R.id.btnHistoryClear)
        val btnClose = view.findViewById<MaterialButton>(R.id.btnHistoryClose)

        val historyList = repo.getAllHistory()
        val userMap = repo.getAllUsers().associate { it.id to it.nama }
        rvHistory.layoutManager = LinearLayoutManager(this)
        rvHistory.adapter = HistoryAdapter(historyList, userMap)

        val dialog = AlertDialog.Builder(this)
            .setView(view)
            .create()

        btnClear.setOnClickListener {
            repo.clearHistory()
            rvHistory.adapter = HistoryAdapter(emptyList(), userMap)
            Toast.makeText(this, "Riwayat berhasil dibersihkan", Toast.LENGTH_SHORT).show()
            refreshDashboard()
        }

        btnClose.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun testAlarmSound() {
        Toast.makeText(this, "Menguji coba alarm pop-up & dering...", Toast.LENGTH_SHORT).show()
        val intent = Intent(this, AlarmActivity::class.java).apply {
            putExtra(AlarmScheduler.EXTRA_MED_ID, 999)
            putExtra(AlarmScheduler.EXTRA_MED_NAME, "Uji Coba Alarm")
            putExtra(AlarmScheduler.EXTRA_MED_DOSIS, "1 Tablet")
            putExtra(AlarmScheduler.EXTRA_MED_SESI, "pagi")
            putExtra(AlarmScheduler.EXTRA_MED_SESI_NAMA, "🌅 Pagi")
            putExtra(AlarmScheduler.EXTRA_MED_JAM, "08:00")
            putExtra(AlarmScheduler.EXTRA_MED_ATURAN, "Sesudah Makan")
            putExtra(AlarmScheduler.EXTRA_MED_STOK, 30)
            putExtra(AlarmScheduler.EXTRA_MED_SATUAN, "Tablet")
            putExtra(AlarmScheduler.EXTRA_MED_KURANGI, 1)
        }
        startActivity(intent)
    }

    private fun requestPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    101
                )
            }
        }
    }

    // ─── FITUR INTEGRASI SAMBUNGKAN KE AKUN GOOGLE ──────────────────
    private fun getGoogleSignInClient(): GoogleSignInClient {
        val clientId = repo.getGoogleClientId()
        val builder = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestProfile()
        if (clientId.isNotEmpty()) {
            builder.requestIdToken(clientId)
        }
        return GoogleSignIn.getClient(this, builder.build())
    }

    private fun handleGoogleSignInResult(completedTask: Task<GoogleSignInAccount>) {
        try {
            val account = completedTask.getResult(ApiException::class.java)
            val email = account.email ?: ""
            val name = account.displayName ?: email.substringBefore('@')
            val id = account.id ?: ""
            val photo = account.photoUrl?.toString() ?: ""
            val idToken = account.idToken ?: ""
            val now = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date())

            val googleAccount = GoogleAccount(
                isConnected = true,
                email = email,
                displayName = name,
                googleId = id,
                photoUrl = photo,
                idToken = idToken,
                connectedAt = now
            )
            repo.saveGoogleAccount(googleAccount)
            refreshDashboard()
            setupUserSpinner()

            MaterialAlertDialogBuilder(this)
                .setTitle("✅ Akun Google Terhubung!")
                .setMessage("Selamat datang, $name!\nAkun Google ($email) telah berhasil disambungkan ke profil MedRemind Anda.")
                .setPositiveButton("Bagus", null)
                .show()
        } catch (e: ApiException) {
            val errCode = e.statusCode
            val errMsg = when (errCode) {
                12500 -> "Google Play Services belum terpasang atau perlu diperbarui."
                12501 -> "Masuk dengan Google dibatalkan oleh pengguna."
                12502 -> "Koneksi ke server Google terputus."
                10 -> "Konfigurasi OAuth (SHA-1 / Client ID) belum didaftarkan di Google Cloud Console. Anda tetap bisa menggunakan 'Sambungkan Manual dengan Email Google'."
                else -> "Gagal masuk (${e.statusCode}): ${e.localizedMessage ?: "Kesalahan autentikasi"}"
            }

            if (errCode != 12501) {
                MaterialAlertDialogBuilder(this)
                    .setTitle("Info Masuk Google")
                    .setMessage("$errMsg\n\nIngin menyambungkan dengan memasukkan alamat email Google secara manual?")
                    .setPositiveButton("Sambung Manual") { _, _ ->
                        showManualGoogleDialog()
                    }
                    .setNegativeButton("Tutup", null)
                    .show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showGoogleAccountDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_google_account, null)
        val tvGoogleStatus = view.findViewById<TextView>(R.id.tvGoogleStatus)
        val tvGoogleAccountDetail = view.findViewById<TextView>(R.id.tvGoogleAccountDetail)
        val btnGoogleSignIn = view.findViewById<MaterialButton>(R.id.btnGoogleSignIn)
        val btnGoogleManual = view.findViewById<MaterialButton>(R.id.btnGoogleManual)
        val btnGoogleDisconnect = view.findViewById<MaterialButton>(R.id.btnGoogleDisconnect)
        val etServerUrl = view.findViewById<EditText>(R.id.etServerUrl)
        val etGoogleClientId = view.findViewById<EditText>(R.id.etGoogleClientId)
        val btnSaveServerConfig = view.findViewById<MaterialButton>(R.id.btnSaveServerConfig)
        val btnSyncServer = view.findViewById<MaterialButton>(R.id.btnSyncServer)
        val btnGoogleClose = view.findViewById<MaterialButton>(R.id.btnGoogleClose)

        etServerUrl.setText(repo.getServerUrl())
        etGoogleClientId.setText(repo.getGoogleClientId())

        val dialog = AlertDialog.Builder(this)
            .setView(view)
            .create()

        fun updateUi() {
            val acc = repo.getGoogleAccount()
            if (acc.isConnected) {
                tvGoogleStatus.text = "✅ Akun Google Terhubung"
                tvGoogleStatus.setTextColor(ContextCompat.getColor(this, R.color.success))
                val detail = buildString {
                    append("👤 Nama: ${acc.displayName}\n")
                    append("📧 Email: ${acc.email}\n")
                    if (acc.connectedAt.isNotEmpty()) {
                        append("🕒 Tersambung: ${acc.connectedAt}")
                    }
                }
                tvGoogleAccountDetail.text = detail
                btnGoogleDisconnect.visibility = View.VISIBLE
                btnGoogleSignIn.text = "🔄 Ganti Akun Google Lain"
            } else {
                tvGoogleStatus.text = "⚠️ Belum Terhubung ke Akun Google"
                tvGoogleStatus.setTextColor(ContextCompat.getColor(this, R.color.warning))
                tvGoogleAccountDetail.text = "Silakan masuk dengan akun Google Anda untuk mengaktifkan sinkronisasi otomatis antar HP & Komputer."
                btnGoogleDisconnect.visibility = View.GONE
                btnGoogleSignIn.text = "🚀 Sambungkan Akun Google (Satu Klik)"
            }
        }
        updateUi()

        btnGoogleSignIn.setOnClickListener {
            val clientId = etGoogleClientId.text.toString().trim()
            if (clientId.isNotEmpty()) {
                repo.saveGoogleClientId(clientId)
            }
            dialog.dismiss()
            try {
                val client = getGoogleSignInClient()
                googleSignInLauncher.launch(client.signInIntent)
            } catch (e: Exception) {
                Toast.makeText(this, "Membuka Google Sign-In: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }

        btnGoogleManual.setOnClickListener {
            dialog.dismiss()
            showManualGoogleDialog()
        }

        btnGoogleDisconnect.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Putuskan Akun Google")
                .setMessage("Yakin ingin memutuskan sambungan akun Google dari aplikasi ini?")
                .setPositiveButton("Putuskan") { _, _ ->
                    repo.disconnectGoogleAccount()
                    try {
                        getGoogleSignInClient().signOut()
                    } catch (_: Exception) {}
                    updateUi()
                    refreshDashboard()
                    setupUserSpinner()
                    Toast.makeText(this, "Sambungan akun Google diputuskan.", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Batal", null)
                .show()
        }

        btnSaveServerConfig.setOnClickListener {
            val url = etServerUrl.text.toString().trim()
            val clientId = etGoogleClientId.text.toString().trim()
            if (url.isNotEmpty()) repo.saveServerUrl(url)
            repo.saveGoogleClientId(clientId)
            Toast.makeText(this, "💾 Konfigurasi server & Google Client ID disimpan!", Toast.LENGTH_SHORT).show()
        }

        btnSyncServer.setOnClickListener {
            val url = etServerUrl.text.toString().trim()
            if (url.isEmpty()) {
                Toast.makeText(this, "Masukkan alamat server terlebih dahulu!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            repo.saveServerUrl(url)

            val acc = repo.getGoogleAccount()
            if (!acc.isConnected) {
                Toast.makeText(this, "Sambungkan akun Google terlebih dahulu sebelum sinkron ke server!", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            Toast.makeText(this, "⏳ Menghubungkan ke $url...", Toast.LENGTH_SHORT).show()
            repo.syncGoogleWithServer(url) { success, msg ->
                MaterialAlertDialogBuilder(this)
                    .setTitle(if (success) "✅ Sinkronisasi Berhasil" else "⚠️ Info Sinkronisasi")
                    .setMessage(msg)
                    .setPositiveButton("OK", null)
                    .show()
            }
        }

        btnGoogleClose.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun showManualGoogleDialog() {
        val input = EditText(this).apply {
            hint = "contoh: nama@gmail.com"
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            val current = repo.getGoogleAccount().email
            if (current.isNotEmpty()) setText(current)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("✏️ Sambungkan Email Google")
            .setMessage("Masukkan alamat email Google Anda untuk disambungkan ke profil MedRemind:")
            .setView(input)
            .setPositiveButton("Simpan") { _, _ ->
                val email = input.text.toString().trim()
                if (email.contains("@")) {
                    val name = email.substringBefore('@').replaceFirstChar { it.uppercase() }
                    val now = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date())
                    val acc = GoogleAccount(
                        isConnected = true,
                        email = email,
                        displayName = name,
                        googleId = "manual_${System.currentTimeMillis()}",
                        photoUrl = "",
                        idToken = "",
                        connectedAt = now
                    )
                    repo.saveGoogleAccount(acc)
                    refreshDashboard()
                    setupUserSpinner()
                    Toast.makeText(this, "✅ Akun Google ($email) tersambung!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Alamat email tidak valid!", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}
