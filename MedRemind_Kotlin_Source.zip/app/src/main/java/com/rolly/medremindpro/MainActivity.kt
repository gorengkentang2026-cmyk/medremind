package com.rolly.medremindpro

import android.Manifest
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import com.google.android.material.tabs.TabLayout
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Layar Utama Dashboard MedRemind Pro
 * 100% Persis dengan Python MedRemind Pro (Desktop & Mobile)
 * Release by Rolly
 */
class MainActivity : AppCompatActivity() {

    private lateinit var repo: MedicationRepository
    private lateinit var adapter: MedicationAdapter

    private lateinit var tvGreeting: TextView
    private lateinit var tvDigitalClock: TextView
    private lateinit var tvMetricTotal: TextView
    private lateinit var tvMetricTaken: TextView
    private lateinit var tvMetricPending: TextView
    private lateinit var tvMetricLowStock: TextView
    private lateinit var tvNextSchedule: TextView

    private lateinit var tabLayout: TabLayout
    private lateinit var rvMedications: RecyclerView
    private lateinit var tvEmptyState: TextView
    private lateinit var fabAdd: ExtendedFloatingActionButton

    private val clockHandler = Handler(Looper.getMainLooper())
    private val clockRunnable = object : Runnable {
        override fun run() {
            updateClockAndGreeting()
            clockHandler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        repo = MedicationRepository(this)

        initViews()
        requestPermissionsIfNeeded()

        // Pasang seluruh jadwal alarm saat aplikasi dibuka
        AlarmScheduler.scheduleAll(this)

        refreshDashboard()
    }

    override fun onResume() {
        super.onResume()
        clockHandler.post(clockRunnable)
        refreshDashboard()
    }

    override fun onPause() {
        super.onPause()
        clockHandler.removeCallbacks(clockRunnable)
    }

    private fun initViews() {
        tvGreeting = findViewById(R.id.tvGreeting)
        tvDigitalClock = findViewById(R.id.tvDigitalClock)
        tvMetricTotal = findViewById(R.id.tvMetricTotal)
        tvMetricTaken = findViewById(R.id.tvMetricTaken)
        tvMetricPending = findViewById(R.id.tvMetricPending)
        tvMetricLowStock = findViewById(R.id.tvMetricLowStock)
        tvNextSchedule = findViewById(R.id.tvNextSchedule)

        tabLayout = findViewById(R.id.tabLayoutMain)
        rvMedications = findViewById(R.id.rvMedications)
        tvEmptyState = findViewById(R.id.tvEmptyState)
        fabAdd = findViewById(R.id.fabAddMedication)

        findViewById<MaterialButton>(R.id.btnNavWhatsApp).setOnClickListener {
            showWhatsAppDialog()
        }

        findViewById<MaterialButton>(R.id.btnNavHistory).setOnClickListener {
            showHistoryDialog()
        }

        findViewById<MaterialButton>(R.id.btnNavTestAlarm).setOnClickListener {
            testAlarmSound()
        }

        fabAdd.setOnClickListener {
            showAddEditDialog(null)
        }

        adapter = MedicationAdapter(
            context = this,
            repo = repo,
            onTakeScheduleClick = { item ->
                repo.markTaken(item.med.id, item.sesiKey, item.sesiNama)
                Toast.makeText(this, "✔ Berhasil minum ${item.med.nama} (${item.sesiNama})!", Toast.LENGTH_SHORT).show()
                refreshDashboard()
            },
            onRestockClick = { med ->
                repo.restock(med.id, 10)
                Toast.makeText(this, "📦 +10 ${med.satuan} stok ditambahkan untuk ${med.nama}!", Toast.LENGTH_SHORT).show()
                refreshDashboard()
            },
            onEditClick = { med ->
                showAddEditDialog(med)
            },
            onDeleteClick = { med ->
                MaterialAlertDialogBuilder(this)
                    .setTitle("Hapus Obat")
                    .setMessage("Yakin ingin menghapus '${med.nama}' beserta seluruh jadwalnya?")
                    .setPositiveButton("Hapus") { _, _ ->
                        AlarmScheduler.cancelMedication(this, med.id)
                        repo.deleteMedication(med.id)
                        Toast.makeText(this, "Obat '${med.nama}' berhasil dihapus", Toast.LENGTH_SHORT).show()
                        refreshDashboard()
                    }
                    .setNegativeButton("Batal", null)
                    .show()
            }
        )

        rvMedications.layoutManager = LinearLayoutManager(this)
        rvMedications.adapter = adapter

        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                loadTabData()
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun updateClockAndGreeting() {
        val now = Calendar.getInstance()
        val hour = now.get(Calendar.HOUR_OF_DAY)
        val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        tvDigitalClock.text = timeStr

        val greeting = when (hour) {
            in 4..10 -> "Selamat Pagi 🌅"
            in 11..14 -> "Selamat Siang ☀"
            in 15..17 -> "Selamat Sore 🌤"
            else -> "Selamat Malam 🌙"
        }
        tvGreeting.text = greeting
    }

    private fun refreshDashboard() {
        val metrics = repo.getMetrics()
        tvMetricTotal.text = metrics.totalObat.toString()
        tvMetricTaken.text = metrics.sudahDiminum.toString()
        tvMetricPending.text = metrics.menunggu.toString()
        tvMetricLowStock.text = metrics.stokMenipis.toString()

        tvNextSchedule.text = "⏰ Jadwal Berikut: ${repo.getNextScheduleInfo()}"

        loadTabData()
    }

    private fun loadTabData() {
        val isTodayTab = tabLayout.selectedTabPosition == 0
        if (isTodayTab) {
            val todayList = repo.getTodaySchedule()
            adapter.setTodayScheduleData(todayList)
            tvEmptyState.text = "Tidak ada jadwal minum obat untuk hari ini (${repo.getHariIni()})."
            tvEmptyState.visibility = if (todayList.isEmpty()) View.VISIBLE else View.GONE
        } else {
            val allList = repo.getAllMedications()
            adapter.setAllMedicationsData(allList)
            tvEmptyState.text = "Belum ada daftar obat tersimpan.\nTekan tombol ➕ Tambah Obat di bawah."
            tvEmptyState.visibility = if (allList.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun showAddEditDialog(medToEdit: Medication?) {
        val view = layoutInflater.inflate(R.layout.dialog_add_edit, null)
        val tvTitle = view.findViewById<TextView>(R.id.tvDialogTitle)
        val etName = view.findViewById<EditText>(R.id.etMedName)
        val etDosis = view.findViewById<EditText>(R.id.etMedDosis)
        val spSatuan = view.findViewById<Spinner>(R.id.spMedSatuan)
        val etStock = view.findViewById<EditText>(R.id.etMedStock)
        val etKurangi = view.findViewById<EditText>(R.id.etMedKurangi)
        val spRule = view.findViewById<Spinner>(R.id.spMedRule)
        val etNote = view.findViewById<EditText>(R.id.etMedNote)

        val cbPagi = view.findViewById<CheckBox>(R.id.cbSesiPagi)
        val etJamPagi = view.findViewById<EditText>(R.id.etJamPagi)
        val cbSiang = view.findViewById<CheckBox>(R.id.cbSesiSiang)
        val etJamSiang = view.findViewById<EditText>(R.id.etJamSiang)
        val cbSore = view.findViewById<CheckBox>(R.id.cbSesiSore)
        val etJamSore = view.findViewById<EditText>(R.id.etJamSore)

        val spHariTipe = view.findViewById<Spinner>(R.id.spHariTipe)
        val layoutHariChecks = view.findViewById<LinearLayout>(R.id.layoutHariChecks)

        val cbSenin = view.findViewById<CheckBox>(R.id.cbHariSenin)
        val cbSelasa = view.findViewById<CheckBox>(R.id.cbHariSelasa)
        val cbRabu = view.findViewById<CheckBox>(R.id.cbHariRabu)
        val cbKamis = view.findViewById<CheckBox>(R.id.cbHariKamis)
        val cbJumat = view.findViewById<CheckBox>(R.id.cbHariJumat)
        val cbSabtu = view.findViewById<CheckBox>(R.id.cbHariSabtu)
        val cbMinggu = view.findViewById<CheckBox>(R.id.cbHariMinggu)

        val btnCancel = view.findViewById<MaterialButton>(R.id.btnDialogCancel)
        val btnSave = view.findViewById<MaterialButton>(R.id.btnDialogSave)

        // Setup Spinners
        val satuanAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, MedicationRepository.DAFTAR_SATUAN)
        spSatuan.adapter = satuanAdapter

        val ruleAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, MedicationRepository.DAFTAR_ATURAN)
        spRule.adapter = ruleAdapter

        val hariTipeList = listOf("Setiap Hari", "Pilih Hari Tertentu")
        val hariTipeAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, hariTipeList)
        spHariTipe.adapter = hariTipeAdapter

        spHariTipe.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, position: Int, id: Long) {
                layoutHariChecks.visibility = if (position == 1) View.VISIBLE else View.GONE
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // Setup TimePickers
        fun setupTimePicker(editText: EditText) {
            editText.setOnClickListener {
                val current = editText.text.toString().split(":")
                val h = current.getOrNull(0)?.toIntOrNull() ?: 8
                val m = current.getOrNull(1)?.toIntOrNull() ?: 0
                TimePickerDialog(this, { _, selectedH, selectedM ->
                    editText.setText(String.format(Locale.getDefault(), "%02d:%02d", selectedH, selectedM))
                }, h, m, true).show()
            }
        }
        setupTimePicker(etJamPagi)
        setupTimePicker(etJamSiang)
        setupTimePicker(etJamSore)

        // Populate jika Edit
        if (medToEdit != null) {
            tvTitle.text = "Edit Jadwal Obat"
            etName.setText(medToEdit.nama)
            etDosis.setText(medToEdit.dosis)
            val satIndex = MedicationRepository.DAFTAR_SATUAN.indexOf(medToEdit.satuan)
            if (satIndex >= 0) spSatuan.setSelection(satIndex)
            etStock.setText(medToEdit.stok.toString())
            etKurangi.setText(medToEdit.kurangiPerMinum.toString())
            val ruleIndex = MedicationRepository.DAFTAR_ATURAN.indexOf(medToEdit.aturan)
            if (ruleIndex >= 0) spRule.setSelection(ruleIndex)
            etNote.setText(medToEdit.catatan)

            cbPagi.isChecked = medToEdit.sesiPagiAktif
            etJamPagi.setText(medToEdit.jamPagi)
            cbSiang.isChecked = medToEdit.sesiSiangAktif
            etJamSiang.setText(medToEdit.jamSiang)
            cbSore.isChecked = medToEdit.sesiSoreAktif
            etJamSore.setText(medToEdit.jamSore)

            if (medToEdit.hariTipe == "Pilih Hari Tertentu") {
                spHariTipe.setSelection(1)
                layoutHariChecks.visibility = View.VISIBLE
                val ha = medToEdit.hariAktif
                cbSenin.isChecked = ha.contains("Senin")
                cbSelasa.isChecked = ha.contains("Selasa")
                cbRabu.isChecked = ha.contains("Rabu")
                cbKamis.isChecked = ha.contains("Kamis")
                cbJumat.isChecked = ha.contains("Jumat")
                cbSabtu.isChecked = ha.contains("Sabtu")
                cbMinggu.isChecked = ha.contains("Minggu")
            } else {
                spHariTipe.setSelection(0)
                layoutHariChecks.visibility = View.GONE
            }
        }

        val dialog = AlertDialog.Builder(this)
            .setView(view)
            .create()

        btnCancel.setOnClickListener { dialog.dismiss() }

        btnSave.setOnClickListener {
            val name = etName.text.toString().trim()
            if (name.isEmpty()) {
                etName.error = "Nama obat wajib diisi!"
                return@setOnClickListener
            }

            val pagiAktif = cbPagi.isChecked
            val siangAktif = cbSiang.isChecked
            val soreAktif = cbSore.isChecked

            if (!pagiAktif && !siangAktif && !soreAktif) {
                Toast.makeText(this, "Aktifkan minimal 1 sesi waktu minum obat!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val hariTipe = spHariTipe.selectedItem.toString()
            val hariAktifList = mutableListOf<String>()
            if (hariTipe == "Pilih Hari Tertentu") {
                if (cbSenin.isChecked) hariAktifList.add("Senin")
                if (cbSelasa.isChecked) hariAktifList.add("Selasa")
                if (cbRabu.isChecked) hariAktifList.add("Rabu")
                if (cbKamis.isChecked) hariAktifList.add("Kamis")
                if (cbJumat.isChecked) hariAktifList.add("Jumat")
                if (cbSabtu.isChecked) hariAktifList.add("Sabtu")
                if (cbMinggu.isChecked) hariAktifList.add("Minggu")

                if (hariAktifList.isEmpty()) {
                    Toast.makeText(this, "Pilih minimal 1 hari aktif!", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
            } else {
                hariAktifList.addAll(MedicationRepository.DAFTAR_HARI)
            }

            val stock = etStock.text.toString().toIntOrNull() ?: 30
            val kurangi = etKurangi.text.toString().toIntOrNull() ?: 1
            val dosis = etDosis.text.toString().trim().ifEmpty { "1 Tablet" }
            val satuan = spSatuan.selectedItem.toString()
            val rule = spRule.selectedItem.toString()
            val note = etNote.text.toString().trim().ifEmpty { "-" }

            val med = medToEdit ?: Medication()
            med.nama = name
            med.dosis = dosis
            med.stok = stock
            med.satuan = satuan
            med.kurangiPerMinum = kurangi
            med.aturan = rule
            med.catatan = note
            med.hariTipe = hariTipe
            med.hariAktif = hariAktifList

            med.sesiPagiAktif = pagiAktif
            med.jamPagi = etJamPagi.text.toString().trim().ifEmpty { "07:00" }

            med.sesiSiangAktif = siangAktif
            med.jamSiang = etJamSiang.text.toString().trim().ifEmpty { "13:00" }

            med.sesiSoreAktif = soreAktif
            med.jamSore = etJamSore.text.toString().trim().ifEmpty { "19:00" }

            med.jam = if (pagiAktif) med.jamPagi else if (siangAktif) med.jamSiang else med.jamSore

            val savedId = repo.addOrUpdateMedication(med)
            med.id = savedId

            // Pasang alarm sistem Android
            AlarmScheduler.scheduleMedication(this, med)

            dialog.dismiss()
            Toast.makeText(this, "✅ Jadwal obat '${med.nama}' berhasil disimpan!", Toast.LENGTH_SHORT).show()
            refreshDashboard()
        }

        dialog.show()
    }

    private fun showWhatsAppDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_whatsapp, null)
        val cbEnabled = view.findViewById<CheckBox>(R.id.cbWaEnabled)
        val etPhone = view.findViewById<EditText>(R.id.etWaNumber)
        val etApiKey = view.findViewById<EditText>(R.id.etWaApiKey)
        val btnCancel = view.findViewById<MaterialButton>(R.id.btnWaCancel)
        val btnTest = view.findViewById<MaterialButton>(R.id.btnWaTest)
        val btnSave = view.findViewById<MaterialButton>(R.id.btnWaSave)

        val (savedPhone, savedApiKey, isEnabled) = WhatsAppNotifier.getConfig(this)
        cbEnabled.isChecked = isEnabled
        etPhone.setText(savedPhone)
        etApiKey.setText(savedApiKey)

        val dialog = AlertDialog.Builder(this)
            .setView(view)
            .create()

        btnCancel.setOnClickListener { dialog.dismiss() }

        btnTest.setOnClickListener {
            val phone = etPhone.text.toString().trim()
            val apiKey = etApiKey.text.toString().trim()
            if (phone.isEmpty() || apiKey.isEmpty()) {
                Toast.makeText(this, "Isi nomor WhatsApp dan API Key terlebih dahulu!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            Toast.makeText(this, "Mengirim pesan uji coba ke WhatsApp...", Toast.LENGTH_SHORT).show()
            WhatsAppNotifier.sendMessageAsync(phone, apiKey, "🔔 *Uji Coba MedRemind Pro*\nKoneksi WhatsApp berhasil terhubung!") { success ->
                runOnUiThread {
                    if (success) {
                        Toast.makeText(this, "✔ Pesan WhatsApp berhasil terkirim!", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this, "❌ Gagal kirim WhatsApp. Periksa nomor & API Key.", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }

        btnSave.setOnClickListener {
            val phone = etPhone.text.toString().trim()
            val apiKey = etApiKey.text.toString().trim()
            val enabled = cbEnabled.isChecked

            WhatsAppNotifier.saveConfig(this, phone, apiKey, enabled)
            dialog.dismiss()
            Toast.makeText(this, "Pengaturan WhatsApp disimpan", Toast.LENGTH_SHORT).show()
        }

        dialog.show()
    }

    private fun showHistoryDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_history, null)
        val rvHistory = view.findViewById<RecyclerView>(R.id.rvHistoryList)
        val btnClear = view.findViewById<MaterialButton>(R.id.btnHistoryClear)
        val btnClose = view.findViewById<MaterialButton>(R.id.btnHistoryClose)

        val historyList = repo.getAllHistory()
        rvHistory.layoutManager = LinearLayoutManager(this)
        rvHistory.adapter = HistoryAdapter(historyList)

        val dialog = AlertDialog.Builder(this)
            .setView(view)
            .create()

        btnClear.setOnClickListener {
            repo.clearHistory()
            rvHistory.adapter = HistoryAdapter(emptyList())
            Toast.makeText(this, "Riwayat berhasil dibersihkan", Toast.LENGTH_SHORT).show()
            refreshDashboard()
        }

        btnClose.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun testAlarmSound() {
        Toast.makeText(this, "Menguji coba alarm pop-up & dering...", Toast.LENGTH_SHORT).show()
        val intent = Intent(this, AlarmActivity::class.java).apply {
            putExtra(AlarmScheduler.EXTRA_MED_ID, 999)
            putExtra(AlarmScheduler.EXTRA_MED_NAME, "Uji Coba Alarm")
            putExtra(AlarmScheduler.EXTRA_MED_DOSIS, "1 Tablet")
            putExtra(AlarmScheduler.EXTRA_MED_SESI, "pagi")
            putExtra(AlarmScheduler.EXTRA_MED_SESI_NAMA, "🌅 Pagi")
            putExtra(AlarmScheduler.EXTRA_MED_JAM, "08:00")
            putExtra(AlarmScheduler.EXTRA_MED_ATURAN, "Sesudah Makan")
            putExtra(AlarmScheduler.EXTRA_MED_STOK, 30)
            putExtra(AlarmScheduler.EXTRA_MED_SATUAN, "Tablet")
            putExtra(AlarmScheduler.EXTRA_MED_KURANGI, 1)
        }
        startActivity(intent)
    }

    private fun requestPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    101
                )
            }
        }
    }
}
