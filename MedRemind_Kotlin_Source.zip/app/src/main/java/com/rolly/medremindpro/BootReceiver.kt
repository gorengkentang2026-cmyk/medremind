package com.rolly.medremindpro

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Receiver yang otomatis aktif saat HP selesai di-restart/dinyalakan
 * Memastikan semua jadwal alarm terpasang kembali 100% tanpa perlu membuka aplikasi
 * Release by Rolly
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            AlarmScheduler.scheduleAll(context)
        }
    }
}
