package com.rolly.medremindpro

import android.content.Context
import android.util.Log
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

/**
 * Pengirim Pesan Notifikasi WhatsApp Otomatis via CallMeBot API
 * Konversi langsung dari kirim_wa_pengingat.py ke Android Native Kotlin.
 * Release by Rolly
 */
object WhatsAppNotifier {

    private const val TAG = "WhatsAppNotifier"
    private const val PREFS_NAME = "medremind_wa_prefs"
    private const val KEY_WA_NUMBER = "wa_phone_number"
    private const val KEY_WA_APIKEY = "wa_api_key"
    private const val KEY_WA_ENABLED = "wa_enabled"

    fun saveConfig(context: Context, phone: String, apiKey: String, enabled: Boolean) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_WA_NUMBER, phone.trim().removePrefix("+"))
            .putString(KEY_WA_APIKEY, apiKey.trim())
            .putBoolean(KEY_WA_ENABLED, enabled)
            .apply()
    }

    fun getConfig(context: Context): Triple<String, String, Boolean> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val phone = prefs.getString(KEY_WA_NUMBER, "") ?: ""
        val apiKey = prefs.getString(KEY_WA_APIKEY, "") ?: ""
        val enabled = prefs.getBoolean(KEY_WA_ENABLED, false)
        return Triple(phone, apiKey, enabled)
    }

    fun sendReminder(context: Context, medName: String, sesi: String, jam: String, dosis: String, aturan: String, sisaStok: Int) {
        val (phone, apiKey, enabled) = getConfig(context)
        if (!enabled || phone.isEmpty() || apiKey.isEmpty()) {
            return
        }

        val message = """
            ⏰ *PENGINGAT MINUM OBAT (MedRemind Pro)*
            Halo! Waktunya minum obat:
            
            💊 *Obat:* $medName
            🕐 *Sesi:* $sesi ($jam WIB)
            🥄 *Dosis:* $dosis
            📋 *Aturan:* $aturan
            📦 *Sisa Stok:* $sisaStok
            
            _Pesan otomatis dikirim oleh MedRemind Pro - Release by Rolly_
        """.trimIndent()

        sendMessageAsync(phone, apiKey, message)
    }

    fun sendMessageAsync(phone: String, apiKey: String, message: String, onResult: ((Boolean) -> Unit)? = null) {
        thread {
            var success = false
            try {
                val encodedMsg = URLEncoder.encode(message, "UTF-8")
                val urlString = "https://api.callmebot.com/whatsapp.php?phone=$phone&text=$encodedMsg&apikey=$apiKey"
                val url = URL(urlString)
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "GET"
                conn.connectTimeout = 15000
                conn.readTimeout = 15000
                conn.setRequestProperty("User-Agent", "Mozilla/5.0")

                val responseCode = conn.responseCode
                if (responseCode in 200..299) {
                    val response = conn.inputStream.bufferedReader().use { it.readText() }
                    Log.d(TAG, "WhatsApp sent successfully: $response")
                    success = true
                } else {
                    Log.e(TAG, "Failed to send WhatsApp. HTTP: $responseCode")
                }
                conn.disconnect()
            } catch (e: Exception) {
                Log.e(TAG, "Error sending WhatsApp: ${e.message}")
            }
            onResult?.invoke(success)
        }
    }
}
