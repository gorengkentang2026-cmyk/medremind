package com.rolly.medremindpro

import com.google.gson.annotations.SerializedName

/**
 * Model Data Obat MedRemind Pro (100% Identik dengan Python MedRemind Pro)
 * Release by Rolly
 */
data class Medication(
    @SerializedName("id") var id: Int = 0,
    @SerializedName("nama") var nama: String = "",
    @SerializedName("jam") var jam: String = "07:00",
    @SerializedName("sesi_pagi_aktif") var sesiPagiAktif: Boolean = true,
    @SerializedName("jam_pagi") var jamPagi: String = "07:00",
    @SerializedName("sesi_siang_aktif") var sesiSiangAktif: Boolean = false,
    @SerializedName("jam_siang") var jamSiang: String = "13:00",
    @SerializedName("sesi_sore_aktif") var sesiSoreAktif: Boolean = false,
    @SerializedName("jam_sore") var jamSore: String = "19:00",
    @SerializedName("hari_tipe") var hariTipe: String = "Setiap Hari",
    @SerializedName("hari_aktif") var hariAktif: List<String> = listOf("Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"),
    @SerializedName("dosis") var dosis: String = "1 Tablet",
    @SerializedName("stok") var stok: Int = 30,
    @SerializedName("satuan") var satuan: String = "Tablet",
    @SerializedName("kurangi_per_minum") var kurangiPerMinum: Int = 1,
    @SerializedName("aturan") var aturan: String = "Sesudah Makan",
    @SerializedName("catatan") var catatan: String = "-",
    @SerializedName("terakhir_minum") var terakhirMinum: String = "",
    @SerializedName("terakhir_minum_sesi") var terakhirMinumSesi: MutableMap<String, MutableList<String>> = mutableMapOf(),
    @SerializedName("user_id") var userId: Int = 1
) {
    fun isActiveOnDay(dayName: String): Boolean {
        return if (hariTipe == "Setiap Hari") {
            true
        } else {
            hariAktif.contains(dayName)
        }
    }
}

/**
 * Model Riwayat Minum Obat
 */
data class HistoryItem(
    @SerializedName("id") val id: Long = System.currentTimeMillis(),
    @SerializedName("obat_id") val medId: Int = 0,
    @SerializedName("nama") val nama: String = "",
    @SerializedName("sesi") val sesi: String = "Pagi",
    @SerializedName("waktu") val waktu: String = "",
    @SerializedName("dosis") val dosis: String = "",
    @SerializedName("sisa_stok") val sisaStok: String = "",
    @SerializedName("aturan") val aturan: String = ""
)

/**
 * Data Statistik Metrik Dashboard
 */
data class DashboardMetrics(
    val totalObat: Int,
    val sudahDiminum: Int,
    val menunggu: Int,
    val stokMenipis: Int
)

/**
 * Data Sesi Jadwal Hari Ini
 */
data class TodayScheduleItem(
    val med: Medication,
    val sesiKey: String,
    val sesiNama: String,
    val jam: String,
    val isDone: Boolean
)
