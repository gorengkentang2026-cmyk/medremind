package com.rolly.medremindpro

import android.content.Context
import android.content.SharedPreferences
import android.media.RingtoneManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Pengelola Database Lokal MedRemind Pro
 * Mendukung Multi-User, Nada Dering Kustom, dan Preferensi Tema Gelap/Terang
 * Release by Rolly
 */
class MedicationRepository(private val context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("medremind_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    companion object {
        private const val KEY_MEDICATIONS = "key_medications"
        private const val KEY_HISTORY = "key_history"
        private const val KEY_USERS = "key_users"
        private const val KEY_ACTIVE_USER_ID = "key_active_user_id"
        private const val KEY_DARK_MODE = "key_dark_mode"
        private const val KEY_RINGTONE_URI = "key_ringtone_uri"
        private const val KEY_RINGTONE_NAME = "key_ringtone_name"
        private const val KEY_GOOGLE_ACCOUNT = "key_google_account"
        private const val KEY_GOOGLE_CLIENT_ID = "key_google_client_id"
        private const val KEY_SERVER_URL = "key_server_url"

        val DAFTAR_HARI = listOf("Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu")
        val DAFTAR_SATUAN = listOf("Tablet", "Kapsul", "Sendok", "Bungkus", "ml", "Sachet")
        val DAFTAR_ATURAN = listOf(
            "Sesudah Makan",
            "Sebelum Makan",
            "Bersama Makan",
            "Saat Makan Malam",
            "Kapan Saja"
        )
    }

    init {
        // Inisialisasi daftar profil pengguna jika kosong
        if (getAllUsers().isEmpty()) {
            val initialUsers = listOf(
                UserProfile(id = 1, nama = "Rolly", hubungan = "Saya")
            )
            saveUsers(initialUsers)
            setActiveUserId(1)
        }

        // Jika data obat masih kosong, isi dengan data contoh
        if (getAllMedications().isEmpty()) {
            val initialList = listOf(
                Medication(
                    id = 1,
                    userId = 1,
                    nama = "Vitamin C 500mg",
                    jam = "08:00",
                    sesiPagiAktif = true,
                    jamPagi = "08:00",
                    sesiSiangAktif = false,
                    jamSiang = "13:00",
                    sesiSoreAktif = false,
                    jamSore = "19:00",
                    hariTipe = "Setiap Hari",
                    hariAktif = DAFTAR_HARI,
                    dosis = "1 Tablet",
                    stok = 30,
                    satuan = "Tablet",
                    kurangiPerMinum = 1,
                    aturan = "Sesudah Makan",
                    catatan = "Minum dengan air hangat"
                )
            )
            saveMedications(initialList)
        }
    }

    // ─── PENGATURAN TEMA GELAP / TERANG ─────────────────────────────
    fun isDarkMode(): Boolean {
        // Default true (tema gelap sesuai desain asli MedRemind)
        return prefs.getBoolean(KEY_DARK_MODE, true)
    }

    fun setDarkMode(isDark: Boolean) {
        prefs.edit().putBoolean(KEY_DARK_MODE, isDark).apply()
    }

    // ─── PENGATURAN NADA DERING KUSTOM ──────────────────────────────
    fun getRingtoneUri(): Uri {
        val uriStr = prefs.getString(KEY_RINGTONE_URI, null)
        return if (!uriStr.isNullOrEmpty()) {
            Uri.parse(uriStr)
        } else {
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        }
    }

    fun getRingtoneName(): String {
        return prefs.getString(KEY_RINGTONE_NAME, "Alarm Bawaan Android") ?: "Alarm Bawaan Android"
    }

    fun setRingtone(uri: Uri?, name: String) {
        prefs.edit()
            .putString(KEY_RINGTONE_URI, uri?.toString())
            .putString(KEY_RINGTONE_NAME, name)
            .apply()
    }

    // ─── MANAJEMEN MULTI-USER / PROFIL KELUARGA ────────────────────
    fun getAllUsers(): MutableList<UserProfile> {
        val json = prefs.getString(KEY_USERS, null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<UserProfile>>() {}.type
        return try {
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun saveUsers(users: List<UserProfile>) {
        prefs.edit().putString(KEY_USERS, gson.toJson(users)).apply()
    }

    fun getActiveUserId(): Int {
        return prefs.getInt(KEY_ACTIVE_USER_ID, 1)
    }

    fun setActiveUserId(id: Int) {
        prefs.edit().putInt(KEY_ACTIVE_USER_ID, id).apply()
    }

    fun getActiveUser(): UserProfile {
        val activeId = getActiveUserId()
        return getAllUsers().find { it.id == activeId } ?: UserProfile(1, "Rolly", "Saya")
    }

    fun addUser(nama: String, hubungan: String): UserProfile {
        val users = getAllUsers()
        val newId = (users.maxOfOrNull { it.id } ?: 0) + 1
        val newUser = UserProfile(id = newId, nama = nama, hubungan = hubungan)
        users.add(newUser)
        saveUsers(users)
        return newUser
    }

    fun deleteUser(userId: Int): Boolean {
        val users = getAllUsers()
        if (users.size <= 1) return false // Sisakan minimal 1 pengguna
        users.removeAll { it.id == userId }
        saveUsers(users)
        if (getActiveUserId() == userId) {
            setActiveUserId(users.first().id)
        }
        return true
    }

    // ─── MANAJEMEN OBAT & JADWAL ────────────────────────────────────
    fun getHariIni(): String {
        return when (Calendar.getInstance().get(Calendar.DAY_OF_WEEK)) {
            Calendar.MONDAY -> "Senin"
            Calendar.TUESDAY -> "Selasa"
            Calendar.WEDNESDAY -> "Rabu"
            Calendar.THURSDAY -> "Kamis"
            Calendar.FRIDAY -> "Jumat"
            Calendar.SATURDAY -> "Sabtu"
            Calendar.SUNDAY -> "Minggu"
            else -> "Senin"
        }
    }

    fun getTodayDate(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }

    fun getAllMedications(): MutableList<Medication> {
        val json = prefs.getString(KEY_MEDICATIONS, null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<Medication>>() {}.type
        return try {
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun getMedicationsForActiveUser(): List<Medication> {
        val activeId = getActiveUserId()
        val all = getAllMedications()
        return if (activeId == 0) {
            all // 0 = Semua Pengguna
        } else {
            all.filter { it.userId == activeId || it.userId == 0 }
        }
    }

    fun saveMedications(list: List<Medication>) {
        val json = gson.toJson(list)
        prefs.edit().putString(KEY_MEDICATIONS, json).apply()
    }

    fun getMedicationById(id: Int): Medication? {
        return getAllMedications().find { it.id == id }
    }

    fun addOrUpdateMedication(med: Medication): Int {
        val list = getAllMedications()
        if (med.userId == 0) {
            med.userId = getActiveUserId()
        }
        val index = list.indexOfFirst { it.id == med.id }
        if (index != -1) {
            list[index] = med
        } else {
            val newId = (list.maxOfOrNull { it.id } ?: 0) + 1
            med.id = newId
            list.add(med)
        }
        saveMedications(list)
        return med.id
    }

    fun deleteMedication(id: Int) {
        val list = getAllMedications()
        list.removeAll { it.id == id }
        saveMedications(list)
    }

    fun restock(id: Int, amount: Int = 10) {
        val list = getAllMedications()
        val med = list.find { it.id == id } ?: return
        med.stok += amount
        saveMedications(list)
    }

    fun isTakenToday(med: Medication, sesiKey: String): Boolean {
        val today = getTodayDate()
        val list = med.terakhirMinumSesi[today] ?: return false
        return list.contains(sesiKey.lowercase())
    }

    fun markTaken(id: Int, sesiKey: String, sesiNama: String = ""): Boolean {
        val list = getAllMedications()
        val med = list.find { it.id == id } ?: return false

        val todayDate = getTodayDate()
        val fullTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

        med.terakhirMinum = todayDate
        val todaySessions = med.terakhirMinumSesi.getOrPut(todayDate) { mutableListOf() }
        val sKey = sesiKey.lowercase()
        if (!todaySessions.contains(sKey)) {
            todaySessions.add(sKey)
        }

        val kurangi = if (med.kurangiPerMinum > 0) med.kurangiPerMinum else 1
        med.stok = maxOf(0, med.stok - kurangi)
        saveMedications(list)

        val sNama = if (sesiNama.isNotEmpty()) sesiNama else when (sKey) {
            "pagi" -> "🌅 Pagi"
            "siang" -> "☀ Siang"
            "sore" -> "🌙 Sore/Malam"
            else -> sesiKey
        }

        addHistory(
            HistoryItem(
                medId = med.id,
                userId = med.userId,
                nama = med.nama,
                sesi = sNama,
                waktu = fullTime,
                dosis = med.dosis,
                sisaStok = "${med.stok} ${med.satuan}",
                aturan = med.aturan
            )
        )
        return true
    }

    // ─── RIWAYAT MINUM ──────────────────────────────────────────────
    fun getAllHistory(): MutableList<HistoryItem> {
        val json = prefs.getString(KEY_HISTORY, null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<HistoryItem>>() {}.type
        val all: MutableList<HistoryItem> = try {
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            mutableListOf()
        }
        val activeId = getActiveUserId()
        return if (activeId == 0) {
            all
        } else {
            all.filter { it.userId == activeId || it.userId == 0 }.toMutableList()
        }
    }

    private fun addHistory(item: HistoryItem) {
        val json = prefs.getString(KEY_HISTORY, null)
        val type = object : TypeToken<MutableList<HistoryItem>>() {}.type
        val list: MutableList<HistoryItem> = try {
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            mutableListOf()
        }
        list.add(0, item)
        prefs.edit().putString(KEY_HISTORY, gson.toJson(list)).apply()
    }

    fun clearHistory() {
        val activeId = getActiveUserId()
        if (activeId == 0) {
            prefs.edit().remove(KEY_HISTORY).apply()
        } else {
            val json = prefs.getString(KEY_HISTORY, null)
            val type = object : TypeToken<MutableList<HistoryItem>>() {}.type
            val list: MutableList<HistoryItem> = try {
                gson.fromJson(json, type) ?: mutableListOf()
            } catch (e: Exception) {
                mutableListOf()
            }
            list.removeAll { it.userId == activeId }
            prefs.edit().putString(KEY_HISTORY, gson.toJson(list)).apply()
        }
    }

    // ─── JADWAL HARI INI & METRIK ───────────────────────────────────
    fun getTodaySchedule(): List<TodayScheduleItem> {
        val hariIni = getHariIni()
        val list = mutableListOf<TodayScheduleItem>()

        for (med in getMedicationsForActiveUser()) {
            if (!med.isActiveOnDay(hariIni)) continue

            if (med.sesiPagiAktif) {
                list.add(
                    TodayScheduleItem(
                        med = med,
                        sesiKey = "pagi",
                        sesiNama = "🌅 Pagi",
                        jam = med.jamPagi,
                        isDone = isTakenToday(med, "pagi")
                    )
                )
            }
            if (med.sesiSiangAktif) {
                list.add(
                    TodayScheduleItem(
                        med = med,
                        sesiKey = "siang",
                        sesiNama = "☀ Siang",
                        jam = med.jamSiang,
                        isDone = isTakenToday(med, "siang")
                    )
                )
            }
            if (med.sesiSoreAktif) {
                list.add(
                    TodayScheduleItem(
                        med = med,
                        sesiKey = "sore",
                        sesiNama = "🌙 Sore/Malam",
                        jam = med.jamSore,
                        isDone = isTakenToday(med, "sore")
                    )
                )
            }
        }

        list.sortBy { it.jam }
        return list
    }

    fun getMetrics(): DashboardMetrics {
        val meds = getMedicationsForActiveUser()
        val total = meds.size
        val todaySchedule = getTodaySchedule()

        val diminum = todaySchedule.count { it.isDone }
        val menunggu = todaySchedule.count { !it.isDone }
        val menipis = meds.count { it.stok in 1..5 }

        return DashboardMetrics(
            totalObat = total,
            sudahDiminum = diminum,
            menunggu = menunggu,
            stokMenipis = menipis
        )
    }

    fun getNextScheduleInfo(): String {
        val nowStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        val todaySchedule = getTodaySchedule()

        if (todaySchedule.isEmpty()) {
            return "Tidak ada jadwal obat untuk hari ini."
        }

        val pending = todaySchedule.filter { !it.isDone }
        if (pending.isEmpty()) {
            return "🎉 Semua sesi obat hari ini telah diminum!"
        }

        val upcoming = pending.firstOrNull { it.jam >= nowStr } ?: pending.first()
        return "${upcoming.jam} WIB — ${upcoming.med.nama} (${upcoming.sesiNama})"
    }

    // ─── INTEGRASI SAMBUNGKAN KE AKUN GOOGLE ────────────────────────
    fun getGoogleAccount(): GoogleAccount {
        val json = prefs.getString(KEY_GOOGLE_ACCOUNT, null) ?: return GoogleAccount()
        return try {
            gson.fromJson(json, GoogleAccount::class.java) ?: GoogleAccount()
        } catch (e: Exception) {
            GoogleAccount()
        }
    }

    fun saveGoogleAccount(acc: GoogleAccount) {
        prefs.edit().putString(KEY_GOOGLE_ACCOUNT, gson.toJson(acc)).apply()
        // Hubungkan ke profil pengguna aktif
        val users = getAllUsers()
        val activeId = getActiveUserId()
        val user = users.find { it.id == activeId }
        if (user != null) {
            user.googleEmail = if (acc.isConnected) acc.email else null
            user.isGoogleConnected = acc.isConnected
            saveUsers(users)
        }
    }

    fun disconnectGoogleAccount() {
        val emptyAcc = GoogleAccount(isConnected = false)
        prefs.edit().putString(KEY_GOOGLE_ACCOUNT, gson.toJson(emptyAcc)).apply()
        val users = getAllUsers()
        val activeId = getActiveUserId()
        val user = users.find { it.id == activeId }
        if (user != null) {
            user.googleEmail = null
            user.isGoogleConnected = false
            saveUsers(users)
        }
    }

    fun isGoogleConnected(): Boolean {
        return getGoogleAccount().isConnected
    }

    fun getGoogleClientId(): String {
        return prefs.getString(KEY_GOOGLE_CLIENT_ID, "") ?: ""
    }

    fun saveGoogleClientId(clientId: String) {
        prefs.edit().putString(KEY_GOOGLE_CLIENT_ID, clientId.trim()).apply()
    }

    fun getServerUrl(): String {
        return prefs.getString(KEY_SERVER_URL, "http://10.0.2.2:5000") ?: "http://10.0.2.2:5000"
    }

    fun saveServerUrl(url: String) {
        prefs.edit().putString(KEY_SERVER_URL, url.trim()).apply()
    }

    /**
     * Sinkronisasi Akun Google ke Server MedRemind (Web & Desktop)
     */
    fun syncGoogleWithServer(
        serverUrl: String,
        onComplete: (success: Boolean, message: String) -> Unit
    ) {
        val account = getGoogleAccount()
        if (!account.isConnected) {
            onComplete(false, "Akun Google belum tersambung di HP.")
            return
        }

        val executor = Executors.newSingleThreadExecutor()
        val mainHandler = Handler(Looper.getMainLooper())

        executor.execute {
            try {
                val cleanUrl = serverUrl.trim().trimEnd('/')
                val targetUrl = URL("$cleanUrl/api/auth/google")
                val conn = targetUrl.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                conn.setRequestProperty("Accept", "application/json")
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                conn.doOutput = true

                val payload = JSONObject().apply {
                    put("email", account.email)
                    put("name", account.displayName.ifEmpty { account.email.substringBefore('@') })
                    put("google_id", account.googleId)
                    put("credential", account.idToken)
                    put("picture", account.photoUrl)
                }

                OutputStreamWriter(conn.outputStream, "UTF-8").use { os ->
                    os.write(payload.toString())
                    os.flush()
                }

                val responseCode = conn.responseCode
                val stream = if (responseCode in 200..299) conn.inputStream else conn.errorStream
                val responseText = stream?.bufferedReader()?.use { it.readText() } ?: ""

                val jsonResp = try { JSONObject(responseText) } catch (e: Exception) { JSONObject() }
                val ok = jsonResp.optBoolean("ok", responseCode in 200..299)
                val msg = jsonResp.optString("msg", if (ok) "Berhasil tersinkron ke Server!" else "Server merespons kode: $responseCode")

                mainHandler.post {
                    onComplete(ok, msg)
                }
            } catch (e: Exception) {
                mainHandler.post {
                    onComplete(false, "Koneksi ke server gagal: ${e.localizedMessage ?: "Timeout / Server offline"}")
                }
            }
        }
    }
}
