package com.rolly.medremindpro

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Pengelola Database Lokal MedRemind Pro
 * 100% Persis dengan Python MedRemind Pro (muat_data, simpan_jadwal, simpan_riwayat)
 * Release by Rolly
 */
class MedicationRepository(private val context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("medremind_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    companion object {
        private const val KEY_MEDICATIONS = "key_medications"
        private const val KEY_HISTORY = "key_history"

        val DAFTAR_HARI = listOf("Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu")
        val DAFTAR_SATUAN = listOf("Tablet", "Kapsul", "Sendok", "Bungkus", "ml", "Sachet")
        val DAFTAR_ATURAN = listOf(
            "Sesudah Makan",
            "Sebelum Makan",
            "Bersama Makan",
            "Saat Makan Malam",
            "Kapan Saja"
        )
    }

    init {
        // Jika data masih kosong, buat data awal default seperti di Python
        if (getAllMedications().isEmpty()) {
            val initialList = listOf(
                Medication(
                    id = 1,
                    nama = "Vitamin C 500mg",
                    jam = "08:00",
                    sesiPagiAktif = true,
                    jamPagi = "08:00",
                    sesiSiangAktif = false,
                    jamSiang = "13:00",
                    sesiSoreAktif = false,
                    jamSore = "19:00",
                    hariTipe = "Setiap Hari",
                    hariAktif = DAFTAR_HARI,
                    dosis = "1 Tablet",
                    stok = 30,
                    satuan = "Tablet",
                    kurangiPerMinum = 1,
                    aturan = "Sesudah Makan",
                    catatan = "Minum dengan air hangat"
                )
            )
            saveMedications(initialList)
        }
    }

    fun getHariIni(): String {
        return when (Calendar.getInstance().get(Calendar.DAY_OF_WEEK)) {
            Calendar.MONDAY -> "Senin"
            Calendar.TUESDAY -> "Selasa"
            Calendar.WEDNESDAY -> "Rabu"
            Calendar.THURSDAY -> "Kamis"
            Calendar.FRIDAY -> "Jumat"
            Calendar.SATURDAY -> "Sabtu"
            Calendar.SUNDAY -> "Minggu"
            else -> "Senin"
        }
    }

    fun getTodayDate(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }

    fun getAllMedications(): MutableList<Medication> {
        val json = prefs.getString(KEY_MEDICATIONS, null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<Medication>>() {}.type
        return try {
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun saveMedications(list: List<Medication>) {
        val json = gson.toJson(list)
        prefs.edit().putString(KEY_MEDICATIONS, json).apply()
    }

    fun getMedicationById(id: Int): Medication? {
        return getAllMedications().find { it.id == id }
    }

    fun addOrUpdateMedication(med: Medication): Int {
        val list = getAllMedications()
        val index = list.indexOfFirst { it.id == med.id }
        if (index != -1) {
            list[index] = med
        } else {
            val newId = (list.maxOfOrNull { it.id } ?: 0) + 1
            med.id = newId
            list.add(med)
        }
        saveMedications(list)
        return med.id
    }

    fun deleteMedication(id: Int) {
        val list = getAllMedications()
        list.removeAll { it.id == id }
        saveMedications(list)
    }

    fun restock(id: Int, amount: Int = 10) {
        val list = getAllMedications()
        val med = list.find { it.id == id } ?: return
        med.stok += amount
        saveMedications(list)
    }

    fun isTakenToday(med: Medication, sesiKey: String): Boolean {
        val today = getTodayDate()
        val list = med.terakhirMinumSesi[today] ?: return false
        return list.contains(sesiKey.lowercase())
    }

    fun markTaken(id: Int, sesiKey: String, sesiNama: String = ""): Boolean {
        val list = getAllMedications()
        val med = list.find { it.id == id } ?: return false

        val todayDate = getTodayDate()
        val fullTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

        med.terakhirMinum = todayDate
        val todaySessions = med.terakhirMinumSesi.getOrPut(todayDate) { mutableListOf() }
        val sKey = sesiKey.lowercase()
        if (!todaySessions.contains(sKey)) {
            todaySessions.add(sKey)
        }

        // Kurangi stok sesuai kurangiPerMinum
        val kurangi = if (med.kurangiPerMinum > 0) med.kurangiPerMinum else 1
        med.stok = maxOf(0, med.stok - kurangi)
        saveMedications(list)

        val sNama = if (sesiNama.isNotEmpty()) sesiNama else when (sKey) {
            "pagi" -> "🌅 Pagi"
            "siang" -> "☀ Siang"
            "sore" -> "🌙 Sore/Malam"
            else -> sesiKey
        }

        // Tambah ke riwayat
        addHistory(
            HistoryItem(
                medId = med.id,
                nama = med.nama,
                sesi = sNama,
                waktu = fullTime,
                dosis = med.dosis,
                sisaStok = "${med.stok} ${med.satuan}",
                aturan = med.aturan
            )
        )
        return true
    }

    fun getAllHistory(): MutableList<HistoryItem> {
        val json = prefs.getString(KEY_HISTORY, null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<HistoryItem>>() {}.type
        return try {
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    private fun addHistory(item: HistoryItem) {
        val list = getAllHistory()
        list.add(0, item) // paling baru di atas
        val json = gson.toJson(list)
        prefs.edit().putString(KEY_HISTORY, json).apply()
    }

    fun clearHistory() {
        prefs.edit().remove(KEY_HISTORY).apply()
    }

    fun getTodaySchedule(): List<TodayScheduleItem> {
        val hariIni = getHariIni()
        val list = mutableListOf<TodayScheduleItem>()

        for (med in getAllMedications()) {
            if (!med.isActiveOnDay(hariIni)) continue

            if (med.sesiPagiAktif) {
                list.add(
                    TodayScheduleItem(
                        med = med,
                        sesiKey = "pagi",
                        sesiNama = "🌅 Pagi",
                        jam = med.jamPagi,
                        isDone = isTakenToday(med, "pagi")
                    )
                )
            }
            if (med.sesiSiangAktif) {
                list.add(
                    TodayScheduleItem(
                        med = med,
                        sesiKey = "siang",
                        sesiNama = "☀ Siang",
                        jam = med.jamSiang,
                        isDone = isTakenToday(med, "siang")
                    )
                )
            }
            if (med.sesiSoreAktif) {
                list.add(
                    TodayScheduleItem(
                        med = med,
                        sesiKey = "sore",
                        sesiNama = "🌙 Sore/Malam",
                        jam = med.jamSore,
                        isDone = isTakenToday(med, "sore")
                    )
                )
            }
        }

        list.sortBy { it.jam }
        return list
    }

    fun getMetrics(): DashboardMetrics {
        val meds = getAllMedications()
        val total = meds.size
        val todaySchedule = getTodaySchedule()

        val diminum = todaySchedule.count { it.isDone }
        val menunggu = todaySchedule.count { !it.isDone }
        val menipis = meds.count { it.stok in 1..5 }

        return DashboardMetrics(
            totalObat = total,
            sudahDiminum = diminum,
            menunggu = menunggu,
            stokMenipis = menipis
        )
    }

    fun getNextScheduleInfo(): String {
        val nowStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        val todaySchedule = getTodaySchedule()

        if (todaySchedule.isEmpty()) {
            return "Tidak ada jadwal obat untuk hari ini."
        }

        val pending = todaySchedule.filter { !it.isDone }
        if (pending.isEmpty()) {
            return "🎉 Semua sesi obat hari ini telah diminum!"
        }

        // Cari yang jamnya setelah sekarang
        val upcoming = pending.firstOrNull { it.jam >= nowStr } ?: pending.first()
        return "${upcoming.jam} WIB — ${upcoming.med.nama} (${upcoming.sesiNama})"
    }
}
