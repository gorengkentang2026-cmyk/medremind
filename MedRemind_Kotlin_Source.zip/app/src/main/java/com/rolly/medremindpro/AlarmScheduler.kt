package com.rolly.medremindpro

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

/**
 * Penjadwal Alarm Presisi Android Native (AlarmManager)
 * Menggunakan setAlarmClock() agar 100% PASTI BERBUNYI meskipun aplikasi ditutup,
 * layar HP mati, atau sistem berada dalam mode hemat baterai (Doze Mode).
 * 100% Mengikuti logika penjadwalan MedRemind Python.
 * Release by Rolly
 */
object AlarmScheduler {

    const val EXTRA_MED_ID = "extra_med_id"
    const val EXTRA_MED_NAME = "extra_med_name"
    const val EXTRA_MED_DOSIS = "extra_med_dosis"
    const val EXTRA_MED_SESI = "extra_med_sesi"
    const val EXTRA_MED_SESI_NAMA = "extra_med_sesi_nama"
    const val EXTRA_MED_ATURAN = "extra_med_aturan"
    const val EXTRA_MED_STOK = "extra_med_stok"
    const val EXTRA_MED_SATUAN = "extra_med_satuan"
    const val EXTRA_MED_KURANGI = "extra_med_kurangi"
    const val EXTRA_MED_JAM = "extra_med_jam"

    fun scheduleAll(context: Context) {
        val repo = MedicationRepository(context)
        val list = repo.getAllMedications()
        for (med in list) {
            scheduleMedication(context, med)
        }
    }

    fun scheduleMedication(context: Context, med: Medication) {
        if (med.sesiPagiAktif) {
            scheduleSingleSession(context, med, "pagi", "🌅 Pagi", med.jamPagi, med.id * 10 + 1)
        } else {
            cancelSingleSession(context, med.id * 10 + 1)
        }

        if (med.sesiSiangAktif) {
            scheduleSingleSession(context, med, "siang", "☀ Siang", med.jamSiang, med.id * 10 + 2)
        } else {
            cancelSingleSession(context, med.id * 10 + 2)
        }

        if (med.sesiSoreAktif) {
            scheduleSingleSession(context, med, "sore", "🌙 Sore/Malam", med.jamSore, med.id * 10 + 3)
        } else {
            cancelSingleSession(context, med.id * 10 + 3)
        }
    }

    private fun scheduleSingleSession(
        context: Context,
        med: Medication,
        sesiKey: String,
        sesiNama: String,
        jamStr: String,
        requestCode: Int
    ) {
        val parts = jamStr.split(":")
        if (parts.size != 2) return
        val jam = parts[0].toIntOrNull() ?: return
        val menit = parts[1].toIntOrNull() ?: return

        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, jam)
            set(Calendar.MINUTE, menit)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        // Jika jam hari ini sudah lewat, jadwalkan untuk besok
        if (target.before(now)) {
            target.add(Calendar.DAY_OF_YEAR, 1)
        }

        // Pastikan jatuh pada hari aktif obat
        var loopSafety = 0
        while (loopSafety < 8) {
            val dayName = when (target.get(Calendar.DAY_OF_WEEK)) {
                Calendar.MONDAY -> "Senin"
                Calendar.TUESDAY -> "Selasa"
                Calendar.WEDNESDAY -> "Rabu"
                Calendar.THURSDAY -> "Kamis"
                Calendar.FRIDAY -> "Jumat"
                Calendar.SATURDAY -> "Sabtu"
                Calendar.SUNDAY -> "Minggu"
                else -> "Senin"
            }
            if (med.isActiveOnDay(dayName)) {
                break
            }
            target.add(Calendar.DAY_OF_YEAR, 1)
            loopSafety++
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra(EXTRA_MED_ID, med.id)
            putExtra(EXTRA_MED_NAME, med.nama)
            putExtra(EXTRA_MED_DOSIS, med.dosis)
            putExtra(EXTRA_MED_SESI, sesiKey)
            putExtra(EXTRA_MED_SESI_NAMA, sesiNama)
            putExtra(EXTRA_MED_JAM, jamStr)
            putExtra(EXTRA_MED_ATURAN, med.aturan)
            putExtra(EXTRA_MED_STOK, med.stok)
            putExtra(EXTRA_MED_SATUAN, med.satuan)
            putExtra(EXTRA_MED_KURANGI, med.kurangiPerMinum)
        }

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }

        val pendingIntent = PendingIntent.getBroadcast(context, requestCode, intent, flags)

        val showIntent = Intent(context, MainActivity::class.java)
        val showPendingIntent = PendingIntent.getActivity(context, requestCode, showIntent, flags)

        // Gunakan setAlarmClock() untuk prioritas Jam Beker Android (TIDAK BISA DIBATASI DOZE/BATTERY SAVER)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val alarmClockInfo = AlarmManager.AlarmClockInfo(target.timeInMillis, showPendingIntent)
            alarmManager.setAlarmClock(alarmClockInfo, pendingIntent)
        } else {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, target.timeInMillis, pendingIntent)
        }
    }

    fun cancelMedication(context: Context, medId: Int) {
        cancelSingleSession(context, medId * 10 + 1)
        cancelSingleSession(context, medId * 10 + 2)
        cancelSingleSession(context, medId * 10 + 3)
    }

    private fun cancelSingleSession(context: Context, requestCode: Int) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, AlarmReceiver::class.java)
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_NO_CREATE
        }
        val pendingIntent = PendingIntent.getBroadcast(context, requestCode, intent, flags)
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }
}
