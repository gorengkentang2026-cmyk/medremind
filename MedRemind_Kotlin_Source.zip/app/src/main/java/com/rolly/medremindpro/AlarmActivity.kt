package com.rolly.medremindpro

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.Vibrator
import android.os.VibratorManager
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Layar Pop-Up Penuh Alarm Pengingat Minum Obat
 * 100% Persis dengan AlarmPopup di Python MedRemind.
 * Membunyikan alarm dan getaran berulang sampai tombol aksi ditekan.
 * Release by Rolly
 */
class AlarmActivity : AppCompatActivity() {

    private var mediaPlayer: MediaPlayer? = null
    private var vibrator: Vibrator? = null

    private var medId: Int = 0
    private var medName: String = ""
    private var dosis: String = ""
    private var sesiKey: String = ""
    private var sesiNama: String = ""
    private var jamStr: String = ""
    private var aturan: String = ""
    private var stok: Int = 0
    private var satuan: String = "Tablet"
    private var kurangi: Int = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Bangunkan layar dan tampilkan di atas Lockscreen
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }

        setContentView(R.layout.activity_alarm)

        medId = intent.getIntExtra(AlarmScheduler.EXTRA_MED_ID, 0)
        medName = intent.getStringExtra(AlarmScheduler.EXTRA_MED_NAME) ?: "Obat Anda"
        dosis = intent.getStringExtra(AlarmScheduler.EXTRA_MED_DOSIS) ?: "1 Tablet"
        sesiKey = intent.getStringExtra(AlarmScheduler.EXTRA_MED_SESI) ?: "pagi"
        sesiNama = intent.getStringExtra(AlarmScheduler.EXTRA_MED_SESI_NAMA) ?: "🌅 Pagi"
        jamStr = intent.getStringExtra(AlarmScheduler.EXTRA_MED_JAM) ?: "08:00"
        aturan = intent.getStringExtra(AlarmScheduler.EXTRA_MED_ATURAN) ?: "Sesudah Makan"
        stok = intent.getIntExtra(AlarmScheduler.EXTRA_MED_STOK, 0)
        satuan = intent.getStringExtra(AlarmScheduler.EXTRA_MED_SATUAN) ?: "Tablet"
        kurangi = intent.getIntExtra(AlarmScheduler.EXTRA_MED_KURANGI, 1)

        val tvTitle = findViewById<TextView>(R.id.tvAlarmTitle)
        val tvMedName = findViewById<TextView>(R.id.tvAlarmMedName)
        val tvDetails = findViewById<TextView>(R.id.tvAlarmDetails)

        val btnTake = findViewById<Button>(R.id.btnAlarmTake)
        val btnSnooze = findViewById<Button>(R.id.btnAlarmSnooze)
        val btnDismiss = findViewById<Button>(R.id.btnAlarmDismiss)

        val sisaEst = maxOf(0, stok - kurangi)
        tvTitle.text = "⏰ Waktunya Minum Obat! ($sesiNama • $jamStr WIB)"
        tvMedName.text = medName
        tvDetails.text = "Dosis: $dosis • $aturan\nSisa Stok: $stok $satuan (Est. sisa setelah minum: $sisaEst $satuan)"

        btnTake.setOnClickListener {
            stopAlarm()
            val repo = MedicationRepository(this)
            repo.markTaken(medId, sesiKey, sesiNama)
            Toast.makeText(this, "✔ Berhasil dicatat: $medName ($sesiNama) telah diminum!", Toast.LENGTH_LONG).show()
            finish()
        }

        btnSnooze.setOnClickListener {
            stopAlarm()
            snoozeAlarm(5) // Tunda 5 menit seperti di Python MedRemind
            Toast.makeText(this, "⏰ Alarm ditunda 5 menit untuk $medName", Toast.LENGTH_SHORT).show()
            finish()
        }

        btnDismiss.setOnClickListener {
            stopAlarm()
            Toast.makeText(this, "Sesi minum $medName dilewati", Toast.LENGTH_SHORT).show()
            finish()
        }

        startAlarmSoundAndVibration()
    }

    private fun startAlarmSoundAndVibration() {
        try {
            val alertUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)

            mediaPlayer = MediaPlayer().apply {
                setDataSource(this@AlarmActivity, alertUri)
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                isLooping = true
                prepare()
                start()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        try {
            vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vibratorManager.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            val pattern = longArrayOf(0, 800, 400, 800, 400)
            vibrator?.vibrate(pattern, 0) // 0 = loop
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun stopAlarm() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (e: Exception) {}

        try {
            vibrator?.cancel()
            vibrator = null
        } catch (e: Exception) {}
    }

    private fun snoozeAlarm(minutes: Int) {
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val targetMillis = System.currentTimeMillis() + (minutes * 60 * 1000)

        val intent = Intent(this, AlarmReceiver::class.java).apply {
            putExtra(AlarmScheduler.EXTRA_MED_ID, medId)
            putExtra(AlarmScheduler.EXTRA_MED_NAME, medName)
            putExtra(AlarmScheduler.EXTRA_MED_DOSIS, dosis)
            putExtra(AlarmScheduler.EXTRA_MED_SESI, sesiKey)
            putExtra(AlarmScheduler.EXTRA_MED_SESI_NAMA, sesiNama)
            putExtra(AlarmScheduler.EXTRA_MED_JAM, jamStr)
            putExtra(AlarmScheduler.EXTRA_MED_ATURAN, aturan)
            putExtra(AlarmScheduler.EXTRA_MED_STOK, stok)
            putExtra(AlarmScheduler.EXTRA_MED_SATUAN, satuan)
            putExtra(AlarmScheduler.EXTRA_MED_KURANGI, kurangi)
        }

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        val pendingIntent = PendingIntent.getBroadcast(this, medId * 1000 + 99, intent, flags)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, targetMillis, pendingIntent)
        } else {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, targetMillis, pendingIntent)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopAlarm()
    }
}
