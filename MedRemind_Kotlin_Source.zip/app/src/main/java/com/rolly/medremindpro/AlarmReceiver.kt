package com.rolly.medremindpro

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat

/**
 * Receiver yang terpanggil tepat waktu saat alarm berbunyi
 * 100% Mengirim notifikasi suara, getaran, pop-up layar penuh, dan pengingat WhatsApp
 * Release by Rolly
 */
class AlarmReceiver : BroadcastReceiver() {

    companion object {
        const val CHANNEL_ID = "medremind_alarm_channel"
        const val CHANNEL_NAME = "Pengingat Minum Obat"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val medId = intent.getIntExtra(AlarmScheduler.EXTRA_MED_ID, 0)
        val medName = intent.getStringExtra(AlarmScheduler.EXTRA_MED_NAME) ?: "Obat Anda"
        val dosis = intent.getStringExtra(AlarmScheduler.EXTRA_MED_DOSIS) ?: "1 Dosis"
        val sesiKey = intent.getStringExtra(AlarmScheduler.EXTRA_MED_SESI) ?: "pagi"
        val sesiNama = intent.getStringExtra(AlarmScheduler.EXTRA_MED_SESI_NAMA) ?: "🌅 Pagi"
        val jam = intent.getStringExtra(AlarmScheduler.EXTRA_MED_JAM) ?: "08:00"
        val aturan = intent.getStringExtra(AlarmScheduler.EXTRA_MED_ATURAN) ?: "Sesudah Makan"
        val stok = intent.getIntExtra(AlarmScheduler.EXTRA_MED_STOK, 0)
        val satuan = intent.getStringExtra(AlarmScheduler.EXTRA_MED_SATUAN) ?: "Tablet"
        val kurangi = intent.getIntExtra(AlarmScheduler.EXTRA_MED_KURANGI, 1)

        val repo = MedicationRepository(context)
        val med = repo.getMedicationById(medId)

        // Jika obat sudah diminum pada sesi ini hari ini, jangan bunyikan alarm lagi
        if (med != null && repo.isTakenToday(med, sesiKey)) {
            // Jadwalkan ulang sesi ini untuk jadwal berikutnya
            AlarmScheduler.scheduleMedication(context, med)
            return
        }

        // 1. Buat Intent untuk membuka AlarmActivity (Pop-up Layar Penuh)
        val fullScreenIntent = Intent(context, AlarmActivity::class.java).apply {
            putExtra(AlarmScheduler.EXTRA_MED_ID, medId)
            putExtra(AlarmScheduler.EXTRA_MED_NAME, medName)
            putExtra(AlarmScheduler.EXTRA_MED_DOSIS, dosis)
            putExtra(AlarmScheduler.EXTRA_MED_SESI, sesiKey)
            putExtra(AlarmScheduler.EXTRA_MED_SESI_NAMA, sesiNama)
            putExtra(AlarmScheduler.EXTRA_MED_JAM, jam)
            putExtra(AlarmScheduler.EXTRA_MED_ATURAN, aturan)
            putExtra(AlarmScheduler.EXTRA_MED_STOK, stok)
            putExtra(AlarmScheduler.EXTRA_MED_SATUAN, satuan)
            putExtra(AlarmScheduler.EXTRA_MED_KURANGI, kurangi)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        val fullScreenPendingIntent = PendingIntent.getActivity(context, medId * 100, fullScreenIntent, flags)

        // 2. Siapkan Notifikasi Prioritas Tinggi dengan Suara & Getar
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_ALARM)
                .build()

            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifikasi alarm minum obat tepat waktu"
                enableLights(true)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500, 200, 500)
                setSound(soundUri, audioAttributes)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("⏰ Waktunya Minum Obat! ($sesiNama)")
            .setContentText("$medName ($dosis) • $aturan")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("Waktunya minum $medName dosis $dosis ($aturan).\nSisa stok: $stok $satuan.\nSegera minum dan catat riwayatnya!")
            )
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setSound(soundUri)
            .setVibrate(longArrayOf(0, 500, 200, 500, 200, 500))
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setContentIntent(fullScreenPendingIntent)
            .build()

        notificationManager.notify(medId, notification)

        // 3. Kirim Pengingat WhatsApp jika diaktifkan pengguna
        WhatsAppNotifier.sendReminder(
            context = context,
            medName = medName,
            sesi = sesiNama,
            jam = jam,
            dosis = dosis,
            aturan = aturan,
            sisaStok = stok
        )

        // 4. Buka langsung layarnya jika perangkat aktif
        try {
            context.startActivity(fullScreenIntent)
        } catch (e: Exception) {
            // Ditangani oleh FullScreenIntent
        }

        // 5. Jadwalkan ulang sesi ini untuk esok hari
        if (med != null) {
            AlarmScheduler.scheduleMedication(context, med)
        }
    }
}
