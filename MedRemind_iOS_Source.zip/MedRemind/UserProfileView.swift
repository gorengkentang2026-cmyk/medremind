import SwiftUI

public struct UserProfileView: View {
    @ObservedObject var store: MedicationStore
    @Environment(\.presentationMode) var presentationMode

    @State private var newName: String = ""
    @State private var newRole: String = "Keluarga"
    @State private var showGoogleSheet: Bool = false

    private let bgDark = Color(red: 0.059, green: 0.090, blue: 0.165)
    private let cardBg = Color(red: 0.118, green: 0.161, blue: 0.231)
    private let cardStroke = Color(red: 0.200, green: 0.255, blue: 0.333)
    private let accentBlue = Color(red: 0.008, green: 0.518, blue: 0.780)
    private let dangerRed = Color(red: 0.937, green: 0.267, blue: 0.267)

    public var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text("Tambahkan profil untuk anggota keluarga (misal: Ayah, Ibu, Anak) agar jadwal obat terpisah rapi.")
                        .font(.system(size: 13))
                        .foregroundColor(.gray)

                    // Form Tambah
                    VStack(alignment: .leading, spacing: 8) {
                        Text("➕ Tambah Profil Baru")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(accentBlue)

                        TextField("Nama Pengguna (misal: Ayah)", text: $newName)
                            .padding(10)
                            .background(bgDark)
                            .cornerRadius(8)
                            .foregroundColor(.white)
                            .overlay(RoundedRectangle(cornerRadius: 8).stroke(cardStroke, lineWidth: 1))

                        TextField("Hubungan (misal: Orang Tua, Anak)", text: $newRole)
                            .padding(10)
                            .background(bgDark)
                            .cornerRadius(8)
                            .foregroundColor(.white)
                            .overlay(RoundedRectangle(cornerRadius: 8).stroke(cardStroke, lineWidth: 1))

                        Button(action: {
                            guard !newName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
                            store.addUser(nama: newName.trimmingCharacters(in: .whitespacesAndNewlines), hubungan: newRole)
                            newName = ""
                            newRole = "Keluarga"
                        }) {
                            Text("Simpan Profil Baru")
                                .font(.system(size: 14, weight: .bold))
                                .frame(maxWidth: .infinity)
                                .frame(height: 44)
                                .background(accentBlue)
                                .foregroundColor(.white)
                                .cornerRadius(8)
                        }
                    }
                    .padding(14)
                    .background(cardBg)
                    .cornerRadius(12)
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(cardStroke, lineWidth: 1))

                    // Daftar Profil
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Daftar Profil Saat Ini:")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(.white)

                        ForEach(store.users) { u in
                            HStack {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("👤 \(u.nama) (\(u.hubungan))")
                                        .font(.system(size: 14, weight: .semibold))
                                        .foregroundColor(store.activeUserId == u.id ? accentBlue : .white)

                                    if let gEmail = u.googleEmail, !gEmail.isEmpty {
                                        Text("🌐 Google: \(gEmail)")
                                            .font(.system(size: 11))
                                            .foregroundColor(.green)
                                    }
                                }
                                Spacer()

                                if store.users.count > 1 {
                                    Button(action: {
                                        store.deleteUser(id: u.id)
                                    }) {
                                        Text("🗑 Hapus")
                                            .font(.system(size: 11))
                                            .foregroundColor(dangerRed)
                                    }
                                }
                            }
                            .padding(.vertical, 6)
                            Divider().background(cardStroke)
                        }

                        Button(action: {
                            showGoogleSheet = true
                        }) {
                            HStack {
                                Text("🌐")
                                Text("Sambungkan ke Akun Google")
                                    .font(.system(size: 13, weight: .semibold))
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 40)
                            .foregroundColor(accentBlue)
                            .background(Color.clear)
                            .overlay(RoundedRectangle(cornerRadius: 8).stroke(cardStroke, lineWidth: 1))
                        }
                    }
                    .padding(14)
                    .background(cardBg)
                    .cornerRadius(12)
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(cardStroke, lineWidth: 1))
                }
                .padding(16)
            }
            .background(bgDark.edgesIgnoringSafeArea(.all))
            .navigationBarTitle("👥 Kelola Profil Multi-User", displayMode: .inline)
            .navigationBarItems(trailing: Button("Tutup") {
                presentationMode.wrappedValue.dismiss()
            }.foregroundColor(accentBlue))
            .sheet(isPresented: $showGoogleSheet) {
                GoogleAccountView(store: store)
            }
        }
    }
}
