import Foundation
import SwiftUI
import Combine

public class MedicationStore: ObservableObject {
    @Published public var medications: [Medication] = []
    @Published public var history: [HistoryItem] = []
    @Published public var users: [UserProfile] = []
    @Published public var activeUserId: Int = 1
    @Published public var googleAccount: GoogleAccount = GoogleAccount()
    @Published public var serverUrl: String = "http://10.0.2.2:5000"
    @Published public var googleClientId: String = ""
    @Published public var isDarkMode: Bool = true

    private let KEY_MEDICATIONS = "ios_key_medications"
    private let KEY_HISTORY = "ios_key_history"
    private let KEY_USERS = "ios_key_users"
    private let KEY_ACTIVE_USER_ID = "ios_key_active_user_id"
    private let KEY_GOOGLE_ACCOUNT = "ios_key_google_account"
    private let KEY_SERVER_URL = "ios_key_server_url"
    private let KEY_GOOGLE_CLIENT_ID = "ios_key_google_client_id"
    private let KEY_DARK_MODE = "ios_key_dark_mode"

    public static let DAFTAR_HARI = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"]
    public static let DAFTAR_SATUAN = ["Tablet", "Kapsul", "Sendok", "Bungkus", "ml", "Sachet"]
    public static let DAFTAR_ATURAN = ["Sesudah Makan", "Sebelum Makan", "Bersama Makan", "Saat Makan Malam", "Kapan Saja"]

    public init() {
        loadData()
        NotificationManager.shared.requestAuthorization()
        rescheduleAllNotifications()
    }

    // MARK: - Persistence
    public func loadData() {
        let defaults = UserDefaults.standard

        isDarkMode = defaults.object(forKey: KEY_DARK_MODE) as? Bool ?? true
        serverUrl = defaults.string(forKey: KEY_SERVER_URL) ?? "http://localhost:5000"
        googleClientId = defaults.string(forKey: KEY_GOOGLE_CLIENT_ID) ?? ""

        if let userJson = defaults.data(forKey: KEY_USERS),
           let loadedUsers = try? JSONDecoder().decode([UserProfile].self, from: userJson) {
            users = loadedUsers
        } else {
            users = [UserProfile(id: 1, nama: "Rolly", hubungan: "Saya")]
            saveUsers()
        }

        activeUserId = defaults.integer(forKey: KEY_ACTIVE_USER_ID)
        if activeUserId == 0 && !users.isEmpty {
            activeUserId = users.first?.id ?? 1
        }

        if let medJson = defaults.data(forKey: KEY_MEDICATIONS),
           let loadedMeds = try? JSONDecoder().decode([Medication].self, from: medJson) {
            medications = loadedMeds
        } else {
            medications = [
                Medication(
                    id: 1,
                    userId: 1,
                    nama: "Vitamin C 500mg",
                    jam: "08:00",
                    sesiPagiAktif: true,
                    jamPagi: "08:00",
                    sesiSiangAktif: false,
                    jamSiang: "13:00",
                    sesiSoreAktif: false,
                    jamSore: "19:00",
                    hariTipe: "Setiap Hari",
                    hariAktif: MedicationStore.DAFTAR_HARI,
                    dosis: "1 Tablet",
                    stok: 30,
                    satuan: "Tablet",
                    kurangiPerMinum: 1,
                    aturan: "Sesudah Makan",
                    catatan: "Minum dengan air hangat"
                )
            ]
            saveMedications()
        }

        if let histJson = defaults.data(forKey: KEY_HISTORY),
           let loadedHist = try? JSONDecoder().decode([HistoryItem].self, from: histJson) {
            history = loadedHist
        }

        if let gJson = defaults.data(forKey: KEY_GOOGLE_ACCOUNT),
           let loadedG = try? JSONDecoder().decode(GoogleAccount.self, from: gJson) {
            googleAccount = loadedG
        }
    }

    public func saveMedications() {
        if let data = try? JSONEncoder().encode(medications) {
            UserDefaults.standard.set(data, forKey: KEY_MEDICATIONS)
        }
    }

    public func saveHistory() {
        if let data = try? JSONEncoder().encode(history) {
            UserDefaults.standard.set(data, forKey: KEY_HISTORY)
        }
    }

    public func saveUsers() {
        if let data = try? JSONEncoder().encode(users) {
            UserDefaults.standard.set(data, forKey: KEY_USERS)
        }
    }

    public func saveGoogleAccount(_ acc: GoogleAccount) {
        googleAccount = acc
        if let data = try? JSONEncoder().encode(acc) {
            UserDefaults.standard.set(data, forKey: KEY_GOOGLE_ACCOUNT)
        }
        if let idx = users.firstIndex(where: { $0.id == activeUserId }) {
            users[idx].googleEmail = acc.isConnected ? acc.email : nil
            users[idx].isGoogleConnected = acc.isConnected
            saveUsers()
        }
    }

    public func disconnectGoogleAccount() {
        saveGoogleAccount(GoogleAccount(isConnected: false))
    }

    public func saveServerConfig(url: String, clientId: String) {
        serverUrl = url.trimmingCharacters(in: .whitespacesAndNewlines)
        googleClientId = clientId.trimmingCharacters(in: .whitespacesAndNewlines)
        UserDefaults.standard.set(serverUrl, forKey: KEY_SERVER_URL)
        UserDefaults.standard.set(googleClientId, forKey: KEY_GOOGLE_CLIENT_ID)
    }

    // MARK: - Medication CRUD
    public func addOrUpdateMedication(_ med: Medication) {
        var copy = med
        if copy.userId == 0 {
            copy.userId = activeUserId
        }
        if let idx = medications.firstIndex(where: { $0.id == copy.id }) {
            medications[idx] = copy
        } else {
            let newId = (medications.map { $0.id }.max() ?? 0) + 1
            copy.id = newId
            medications.append(copy)
        }
        saveMedications()
        rescheduleAllNotifications()
    }

    public func deleteMedication(id: Int) {
        medications.removeAll { $0.id == id }
        saveMedications()
        rescheduleAllNotifications()
    }

    public func restock(id: Int, amount: Int = 10) {
        if let idx = medications.firstIndex(where: { $0.id == id }) {
            medications[idx].stok += amount
            saveMedications()
        }
    }

    public func markTaken(medId: Int, sesiKey: String, sesiNama: String) {
        guard let idx = medications.firstIndex(where: { $0.id == medId }) else { return }

        let todayStr = getTodayDate()
        var currentSesi = medications[idx].terakhirMinumSesi[todayStr] ?? []
        if !currentSesi.contains(sesiKey) {
            currentSesi.append(sesiKey)
            medications[idx].terakhirMinumSesi[todayStr] = currentSesi
        }

        let timeStr = DateFormatter.localizedString(from: Date(), dateStyle: .short, timeStyle: .short)
        medications[idx].terakhirMinum = "\(timeStr) (\(sesiNama))"

        let kurangi = medications[idx].kurangiPerMinum
        medications[idx].stok = max(0, medications[idx].stok - kurangi)
        saveMedications()

        let hist = HistoryItem(
            userId: medications[idx].userId,
            medId: medId,
            nama: medications[idx].nama,
            sesi: sesiNama,
            waktu: "\(todayStr) \(DateFormatter.localizedString(from: Date(), dateStyle: .none, timeStyle: .short))",
            dosis: medications[idx].dosis,
            sisaStok: "\(medications[idx].stok) \(medications[idx].satuan)",
            aturan: medications[idx].aturan
        )
        history.insert(hist, at: 0)
        saveHistory()
    }

    // MARK: - Multi-User
    public func addUser(nama: String, hubungan: String) {
        let newId = (users.map { $0.id }.max() ?? 0) + 1
        users.append(UserProfile(id: newId, nama: nama, hubungan: hubungan))
        saveUsers()
    }

    public func deleteUser(id: Int) {
        if users.count <= 1 { return }
        users.removeAll { $0.id == id }
        saveUsers()
        if activeUserId == id {
            activeUserId = users.first?.id ?? 1
            UserDefaults.standard.set(activeUserId, forKey: KEY_ACTIVE_USER_ID)
        }
    }

    public func getActiveUser() -> UserProfile {
        return users.first(where: { $0.id == activeUserId }) ?? UserProfile(id: 1, nama: "Rolly", hubungan: "Saya")
    }

    // MARK: - Schedulers & Metrics
    public func getHariIni() -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "id_ID")
        formatter.dateFormat = "EEEE"
        let day = formatter.string(from: Date())
        return day.capitalized
    }

    public func getTodayDate() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: Date())
    }

    public func getMedicationsForActiveUser() -> [Medication] {
        if activeUserId == 0 {
            return medications
        }
        return medications.filter { $0.userId == activeUserId || $0.userId == 0 }
    }

    public func getTodaySchedule() -> [TodayScheduleItem] {
        let dayName = getHariIni()
        let todayStr = getTodayDate()
        var items: [TodayScheduleItem] = []

        for med in getMedicationsForActiveUser() {
            if !med.isActiveOnDay(dayName) { continue }
            let takenSesi = med.terakhirMinumSesi[todayStr] ?? []

            if med.sesiPagiAktif {
                items.append(TodayScheduleItem(med: med, sesiKey: "pagi", sesiNama: "🌅 Pagi", jam: med.jamPagi, isDone: takenSesi.contains("pagi")))
            }
            if med.sesiSiangAktif {
                items.append(TodayScheduleItem(med: med, sesiKey: "siang", sesiNama: "☀ Siang", jam: med.jamSiang, isDone: takenSesi.contains("siang")))
            }
            if med.sesiSoreAktif {
                items.append(TodayScheduleItem(med: med, sesiKey: "sore", sesiNama: "🌙 Sore/Malam", jam: med.jamSore, isDone: takenSesi.contains("sore")))
            }
        }
        return items.sorted(by: { $0.jam < $1.jam })
    }

    public func getMetrics() -> DashboardMetrics {
        let meds = getMedicationsForActiveUser()
        let schedule = getTodaySchedule()
        return DashboardMetrics(
            totalObat: meds.count,
            sudahDiminum: schedule.filter { $0.isDone }.count,
            menunggu: schedule.filter { !$0.isDone }.count,
            stokMenipis: meds.filter { $0.stok <= 5 }.count
        )
    }

    public func getNextScheduleInfo() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        let nowStr = formatter.string(from: Date())
        let schedule = getTodaySchedule()
        if schedule.isEmpty {
            return "Tidak ada jadwal obat hari ini."
        }
        let pending = schedule.filter { !$0.isDone }
        if pending.isEmpty {
            return "🎉 Semua sesi obat hari ini telah diminum!"
        }
        let upcoming = pending.first(where: { $0.jam >= nowStr }) ?? pending.first!
        return "\(upcoming.jam) WIB — \(upcoming.med.nama) (\(upcoming.sesiNama))"
    }

    public func rescheduleAllNotifications() {
        NotificationManager.shared.removeAll()
        for med in medications {
            if med.sesiPagiAktif {
                NotificationManager.shared.scheduleDose(
                    id: "\(med.id)_pagi",
                    namaObat: med.nama,
                    dosis: med.dosis,
                    aturan: med.aturan,
                    sesiNama: "Pagi",
                    jamStr: med.jamPagi
                )
            }
            if med.sesiSiangAktif {
                NotificationManager.shared.scheduleDose(
                    id: "\(med.id)_siang",
                    namaObat: med.nama,
                    dosis: med.dosis,
                    aturan: med.aturan,
                    sesiNama: "Siang",
                    jamStr: med.jamSiang
                )
            }
            if med.sesiSoreAktif {
                NotificationManager.shared.scheduleDose(
                    id: "\(med.id)_sore",
                    namaObat: med.nama,
                    dosis: med.dosis,
                    aturan: med.aturan,
                    sesiNama: "Sore/Malam",
                    jamStr: med.jamSore
                )
            }
        }
    }

    // MARK: - Server Sync via HTTP
    public func syncGoogleWithServer(completion: @escaping (Bool, String) -> Void) {
        guard googleAccount.isConnected else {
            completion(false, "Sambungkan Akun Google di HP terlebih dahulu!")
            return
        }

        let cleanUrl = serverUrl.trimmingCharacters(in: .whitespacesAndNewlines).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        guard let url = URL(string: "\(cleanUrl)/api/auth/google") else {
            completion(false, "URL Server tidak valid.")
            return
        }

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.timeoutInterval = 8.0

        let payload: [String: Any] = [
            "email": googleAccount.email,
            "name": googleAccount.displayName.isEmpty ? googleAccount.email.components(separatedBy: "@").first ?? "User" : googleAccount.displayName,
            "google_id": googleAccount.googleId,
            "credential": googleAccount.idToken,
            "picture": googleAccount.photoUrl
        ]

        guard let httpBody = try? JSONSerialization.data(withJSONObject: payload, options: []) else {
            completion(false, "Gagal membuat format data JSON.")
            return
        }
        req.httpBody = httpBody

        URLSession.shared.dataTask(with: req) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(false, "Koneksi ke server gagal: \(error.localizedDescription)")
                    return
                }
                guard let data = data,
                      let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] else {
                    completion(false, "Format respons server tidak dikenali.")
                    return
                }
                let ok = json["ok"] as? Bool ?? true
                let msg = json["msg"] as? String ?? "Berhasil sinkronisasi dengan Server!"
                completion(ok, msg)
            }
        }.resume()
    }
}
