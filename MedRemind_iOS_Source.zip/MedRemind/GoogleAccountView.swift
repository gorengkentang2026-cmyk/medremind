import SwiftUI

public struct GoogleAccountView: View {
    @ObservedObject var store: MedicationStore
    @Environment(\.presentationMode) var presentationMode

    @State private var serverUrlInput: String = ""
    @State private var clientIdInput: String = ""
    @State private var manualEmailInput: String = ""
    @State private var showManualAlert: Bool = false
    @State private var alertTitle: String = ""
    @State private var alertMessage: String = ""
    @State private var showAlert: Bool = false
    @State private var isSyncing: Bool = false

    private let bgDark = Color(red: 0.059, green: 0.090, blue: 0.165)
    private let cardBg = Color(red: 0.118, green: 0.161, blue: 0.231)
    private let cardStroke = Color(red: 0.200, green: 0.255, blue: 0.333)
    private let accentBlue = Color(red: 0.008, green: 0.518, blue: 0.780)
    private let googleBlue = Color(red: 0.259, green: 0.522, blue: 0.957)
    private let successGreen = Color(red: 0.063, green: 0.725, blue: 0.506)
    private let dangerRed = Color(red: 0.937, green: 0.267, blue: 0.267)

    public init(store: MedicationStore) {
        self.store = store
        _serverUrlInput = State(initialValue: store.serverUrl)
        _clientIdInput = State(initialValue: store.googleClientId)
    }

    public var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    // Header Subtitle
                    Text("Fitur Akun Google memungkinkan Anda masuk satu klik, mensinkronkan jadwal obat antar HP iPhone dan Komputer secara nirkabel, serta mencadangkan profil Anda.")
                        .font(.system(size: 13))
                        .foregroundColor(Color.gray)

                    // MARK: - Status Card
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Text(store.googleAccount.isConnected ? "✅ Akun Google Terhubung" : "⚠️ Belum Terhubung ke Akun Google")
                                .font(.system(size: 15, weight: .bold))
                                .foregroundColor(store.googleAccount.isConnected ? successGreen : Color.orange)
                            Spacer()
                        }

                        if store.googleAccount.isConnected {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("👤 Nama: \(store.googleAccount.displayName)")
                                    .font(.system(size: 13, weight: .semibold))
                                    .foregroundColor(.white)
                                Text("📧 Email: \(store.googleAccount.email)")
                                    .font(.system(size: 13))
                                    .foregroundColor(.white.opacity(0.85))
                                if !store.googleAccount.connectedAt.isEmpty {
                                    Text("🕒 Tersambung: \(store.googleAccount.connectedAt)")
                                        .font(.system(size: 11))
                                        .foregroundColor(.gray)
                                }
                            }
                        } else {
                            Text("Silakan masuk dengan akun Google Anda untuk mengaktifkan sinkronisasi otomatis antar iPhone & Komputer.")
                                .font(.system(size: 12))
                                .foregroundColor(Color.gray)
                        }
                    }
                    .padding(14)
                    .background(cardBg)
                    .cornerRadius(12)
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(cardStroke, lineWidth: 1))

                    // MARK: - Tombol Aksi Google
                    VStack(spacing: 10) {
                        Button(action: {
                            // Sambungkan Akun Google 1-Klik / Input Dialog
                            manualEmailInput = store.googleAccount.email
                            showManualAlert = true
                        }) {
                            HStack {
                                Text("🚀")
                                Text(store.googleAccount.isConnected ? "Ganti Akun Google" : "Sambungkan Akun Google")
                                    .font(.system(size: 15, weight: .bold))
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 48)
                            .background(googleBlue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                        }

                        if store.googleAccount.isConnected {
                            Button(action: {
                                store.disconnectGoogleAccount()
                                alertTitle = "Sambungan Diputuskan"
                                alertMessage = "Sambungan akun Google telah berhasil diputuskan."
                                showAlert = true
                            }) {
                                HStack {
                                    Text("❌")
                                    Text("Putuskan Sambungan Akun")
                                        .font(.system(size: 14, weight: .semibold))
                                }
                                .frame(maxWidth: .infinity)
                                .frame(height: 44)
                                .foregroundColor(dangerRed)
                                .background(Color.clear)
                                .overlay(RoundedRectangle(cornerRadius: 10).stroke(dangerRed, lineWidth: 1))
                            }
                        }
                    }

                    Divider().background(cardStroke)

                    // MARK: - Sinkronisasi ke Komputer (Server MedRemind)
                    VStack(alignment: .leading, spacing: 12) {
                        Text("💻 Sinkronisasi ke Komputer (Server MedRemind)")
                            .font(.system(size: 15, weight: .bold))
                            .foregroundColor(.white)

                        Text("Sinkronkan data jadwal dan profil ke server desktop Python yang berjalan di komputer (Mulai_Server_HP.bat).")
                            .font(.system(size: 12))
                            .foregroundColor(.gray)

                        VStack(alignment: .leading, spacing: 6) {
                            Text("Alamat Server Komputer:")
                                .font(.system(size: 12))
                                .foregroundColor(.white.opacity(0.8))
                            TextField("cth: http://192.168.1.10:5000", text: $serverUrlInput)
                                .textFieldStyle(PlainTextFieldStyle())
                                .padding(10)
                                .background(bgDark)
                                .cornerRadius(8)
                                .foregroundColor(.white)
                                .overlay(RoundedRectangle(cornerRadius: 8).stroke(cardStroke, lineWidth: 1))
                        }

                        VStack(alignment: .leading, spacing: 6) {
                            Text("Google Client ID (Opsional):")
                                .font(.system(size: 12))
                                .foregroundColor(.white.opacity(0.8))
                            TextField("Client ID dari Google Cloud Console", text: $clientIdInput)
                                .textFieldStyle(PlainTextFieldStyle())
                                .padding(10)
                                .background(bgDark)
                                .cornerRadius(8)
                                .foregroundColor(.white)
                                .overlay(RoundedRectangle(cornerRadius: 8).stroke(cardStroke, lineWidth: 1))
                        }

                        HStack(spacing: 10) {
                            Button(action: {
                                store.saveServerConfig(url: serverUrlInput, clientId: clientIdInput)
                                alertTitle = "Pengaturan Disimpan"
                                alertMessage = "Alamat server & Client ID berhasil disimpan."
                                showAlert = true
                            }) {
                                Text("💾 Simpan URL")
                                    .font(.system(size: 13, weight: .medium))
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 42)
                                    .foregroundColor(.white)
                                    .background(cardBg)
                                    .cornerRadius(8)
                                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(cardStroke, lineWidth: 1))
                            }

                            Button(action: {
                                store.saveServerConfig(url: serverUrlInput, clientId: clientIdInput)
                                isSyncing = true
                                store.syncGoogleWithServer { success, msg in
                                    isSyncing = false
                                    alertTitle = success ? "✅ Sinkronisasi Berhasil" : "⚠️ Info Sinkronisasi"
                                    alertMessage = msg
                                    showAlert = true
                                }
                            }) {
                                HStack {
                                    if isSyncing {
                                        ProgressView().progressViewStyle(CircularProgressViewStyle(tint: .white))
                                    } else {
                                        Text("🔄 Sinkron Sekarang")
                                    }
                                }
                                .font(.system(size: 13, weight: .bold))
                                .frame(maxWidth: .infinity)
                                .frame(height: 42)
                                .foregroundColor(.white)
                                .background(accentBlue)
                                .cornerRadius(8)
                            }
                        }
                    }
                    .padding(14)
                    .background(cardBg)
                    .cornerRadius(12)
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(cardStroke, lineWidth: 1))
                }
                .padding(16)
            }
            .background(bgDark.edgesIgnoringSafeArea(.all))
            .navigationBarTitle("🌐 Akun Google", displayMode: .inline)
            .navigationBarItems(trailing: Button("Tutup") {
                presentationMode.wrappedValue.dismiss()
            }.foregroundColor(accentBlue))
            .alert(isPresented: $showAlert) {
                Alert(title: Text(alertTitle), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            }
        }
        .accentColor(accentBlue)
    }
}
