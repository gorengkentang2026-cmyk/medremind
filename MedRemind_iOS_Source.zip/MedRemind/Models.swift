import Foundation

// MARK: - Model Profil Pengguna (Multi-User)
public struct UserProfile: Identifiable, Codable, Equatable {
    public var id: Int
    public var nama: String
    public var hubungan: String // Misal: Saya, Ayah, Ibu, Anak, Pasien
    public var googleEmail: String?
    public var isGoogleConnected: Bool

    public init(id: Int = 1, nama: String = "Pengguna Utama", hubungan: String = "Saya", googleEmail: String? = null, isGoogleConnected: Bool = false) {
        self.id = id
        self.nama = nama
        self.hubungan = hubungan
        self.googleEmail = googleEmail
        self.isGoogleConnected = isGoogleConnected
    }
}

// MARK: - Model Akun Google
public struct GoogleAccount: Codable, Equatable {
    public var isConnected: Bool
    public var email: String
    public var displayName: String
    public var googleId: String
    public var photoUrl: String
    public var idToken: String
    public var connectedAt: String

    public init(
        isConnected: Bool = false,
        email: String = "",
        displayName: String = "",
        googleId: String = "",
        photoUrl: String = "",
        idToken: String = "",
        connectedAt: String = ""
    ) {
        self.isConnected = isConnected
        self.email = email
        self.displayName = displayName
        self.googleId = googleId
        self.photoUrl = photoUrl
        self.idToken = idToken
        self.connectedAt = connectedAt
    }
}

// MARK: - Model Obat & Jadwal
public struct Medication: Identifiable, Codable, Equatable {
    public var id: Int
    public var userId: Int
    public var nama: String
    public var jam: String
    public var sesiPagiAktif: Bool
    public var jamPagi: String
    public var sesiSiangAktif: Bool
    public var jamSiang: String
    public var sesiSoreAktif: Bool
    public var jamSore: String
    public var hariTipe: String
    public var hariAktif: [String]
    public var dosis: String
    public var stok: Int
    public var satuan: String
    public var kurangiPerMinum: Int
    public var aturan: String
    public var catatan: String
    public var terakhirMinum: String
    public var terakhirMinumSesi: [String: [String]] // [yyyy-MM-dd: ["pagi", "siang"]]

    public init(
        id: Int = 0,
        userId: Int = 1,
        nama: String = "",
        jam: String = "08:00",
        sesiPagiAktif: Bool = true,
        jamPagi: String = "08:00",
        sesiSiangAktif: Bool = false,
        jamSiang: String = "13:00",
        sesiSoreAktif: Bool = false,
        jamSore: String = "19:00",
        hariTipe: String = "Setiap Hari",
        hariAktif: [String] = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"],
        dosis: String = "1 Tablet",
        stok: Int = 30,
        satuan: String = "Tablet",
        kurangiPerMinum: Int = 1,
        aturan: String = "Sesudah Makan",
        catatan: String = "-",
        terakhirMinum: String = "",
        terakhirMinumSesi: [String: [String]] = [:]
    ) {
        self.id = id
        self.userId = userId
        self.nama = nama
        self.jam = jam
        self.sesiPagiAktif = sesiPagiAktif
        self.jamPagi = jamPagi
        self.sesiSiangAktif = sesiSiangAktif
        self.jamSiang = jamSiang
        self.sesiSoreAktif = sesiSoreAktif
        self.jamSore = jamSore
        self.hariTipe = hariTipe
        self.hariAktif = hariAktif
        self.dosis = dosis
        self.stok = stok
        self.satuan = satuan
        self.kurangiPerMinum = kurangiPerMinum
        self.aturan = aturan
        self.catatan = catatan
        self.terakhirMinum = terakhirMinum
        self.terakhirMinumSesi = terakhirMinumSesi
    }

    public func isActiveOnDay(_ dayName: String) -> Bool {
        if hariTipe == "Setiap Hari" {
            return true
        }
        return hariAktif.contains(dayName)
    }
}

// MARK: - Model Riwayat Minum
public struct HistoryItem: Identifiable, Codable, Equatable {
    public var id: Int64
    public var userId: Int
    public var medId: Int
    public var nama: String
    public var sesi: String
    public var waktu: String
    public var dosis: String
    public var sisaStok: String
    public var aturan: String

    public init(
        id: Int64 = Int64(Date().timeIntervalSince1970 * 1000),
        userId: Int = 1,
        medId: Int = 0,
        nama: String = "",
        sesi: String = "Pagi",
        waktu: String = "",
        dosis: String = "",
        sisaStok: String = "",
        aturan: String = ""
    ) {
        self.id = id
        self.userId = userId
        self.medId = medId
        self.nama = nama
        self.sesi = sesi
        self.waktu = waktu
        self.dosis = dosis
        self.sisaStok = sisaStok
        self.aturan = aturan
    }
}

// MARK: - Metrik Dashboard
public struct DashboardMetrics {
    public let totalObat: Int
    public let sudahDiminum: Int
    public let menunggu: Int
    public let stokMenipis: Int
}

// MARK: - Sesi Jadwal Hari Ini
public struct TodayScheduleItem: Identifiable {
    public var id: String { "\(med.id)_\(sesiKey)" }
    public let med: Medication
    public let sesiKey: String
    public let sesiNama: String
    public let jam: String
    public let isDone: Bool
}
