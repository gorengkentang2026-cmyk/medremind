import Foundation
import UserNotifications

public class NotificationManager {
    public static let shared = NotificationManager()

    private init() {}

    public func requestAuthorization() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { granted, error in
            if granted {
                print("✅ Izin Notifikasi iOS diberikan!")
            } else if let error = error {
                print("❌ Gagal meminta izin notifikasi: \(error.localizedDescription)")
            }
        }
    }

    public func scheduleDose(id: String, namaObat: String, dosis: String, aturan: String, sesiNama: String, jamStr: String) {
        let parts = jamStr.split(separator: ":")
        guard parts.count == 2,
              let hour = Int(parts[0]),
              let minute = Int(parts[1]) else { return }

        let content = UNMutableNotificationContent()
        content.title = "⏰ Waktunya Minum Obat! (\(sesiNama))"
        content.body = "\(namaObat) • \(dosis) (\(aturan))"
        content.sound = .defaultCriticalSound(withAudioVolume: 1.0)
        content.categoryIdentifier = "MEDICINE_ALARM"

        var dateComponents = DateComponents()
        dateComponents.hour = hour
        dateComponents.minute = minute

        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: true)
        let request = UNNotificationRequest(identifier: id, content: content, trigger: trigger)

        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("❌ Gagal menjadwalkan notifikasi: \(error.localizedDescription)")
            }
        }
    }

    public func removeNotification(id: String) {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [id])
    }

    public func removeAll() {
        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
    }
}
