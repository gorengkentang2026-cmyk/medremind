import SwiftUI

public struct HistoryView: View {
    @ObservedObject var store: MedicationStore
    @Environment(\.presentationMode) var presentationMode

    private let bgDark = Color(red: 0.059, green: 0.090, blue: 0.165)
    private let cardBg = Color(red: 0.118, green: 0.161, blue: 0.231)
    private let cardStroke = Color(red: 0.200, green: 0.255, blue: 0.333)
    private let dangerRed = Color(red: 0.937, green: 0.267, blue: 0.267)

    public var body: some View {
        NavigationView {
            VStack {
                if store.history.isEmpty {
                    Spacer()
                    VStack(spacing: 8) {
                        Text("📋")
                            .font(.system(size: 48))
                        Text("Belum ada catatan riwayat minum obat.")
                            .font(.system(size: 14))
                            .foregroundColor(.gray)
                    }
                    Spacer()
                } else {
                    List {
                        ForEach(store.history) { item in
                            VStack(alignment: .leading, spacing: 4) {
                                HStack {
                                    Text(item.nama)
                                        .font(.system(size: 15, weight: .bold))
                                        .foregroundColor(.white)
                                    Spacer()
                                    Text(item.sesi)
                                        .font(.system(size: 11, weight: .bold))
                                        .padding(.horizontal, 6)
                                        .padding(.vertical, 2)
                                        .background(Color.blue.opacity(0.3))
                                        .cornerRadius(4)
                                        .foregroundColor(.cyan)
                                }
                                HStack {
                                    Text("🕒 \(item.waktu) • \(item.dosis)")
                                        .font(.system(size: 12))
                                        .foregroundColor(.gray)
                                    Spacer()
                                    Text("Sisa: \(item.sisaStok)")
                                        .font(.system(size: 11))
                                        .foregroundColor(.orange)
                                }
                            }
                            .padding(.vertical, 4)
                            .listRowBackground(cardBg)
                        }
                    }
                    .listStyle(PlainListStyle())
                }
            }
            .background(bgDark.edgesIgnoringSafeArea(.all))
            .navigationBarTitle("📋 Riwayat Minum Obat", displayMode: .inline)
            .navigationBarItems(
                leading: Button(action: {
                    store.history.removeAll()
                    store.saveHistory()
                }) {
                    Text("🗑 Bersihkan")
                        .foregroundColor(dangerRed)
                        .font(.system(size: 13))
                },
                trailing: Button("Tutup") {
                    presentationMode.wrappedValue.dismiss()
                }.foregroundColor(.blue)
            )
        }
    }
}
