import SwiftUI

public struct AddEditMedicationView: View {
    @ObservedObject var store: MedicationStore
    @Environment(\.presentationMode) var presentationMode

    var medToEdit: Medication?

    @State private var nama: String = ""
    @State private var dosis: String = "1 Tablet"
    @State private var satuan: String = "Tablet"
    @State private var stokStr: String = "30"
    @State private var kurangiStr: String = "1"
    @State private var aturan: String = "Sesudah Makan"
    @State private var catatan: String = "-"

    @State private var sesiPagiAktif: Bool = true
    @State private var jamPagi: Date = Date()
    @State private var sesiSiangAktif: Bool = false
    @State private var jamSiang: Date = Date()
    @State private var sesiSoreAktif: Bool = false
    @State private var jamSore: Date = Date()

    @State private var hariTipe: String = "Setiap Hari"
    @State private var selectedHari: [String] = MedicationStore.DAFTAR_HARI

    private let bgDark = Color(red: 0.059, green: 0.090, blue: 0.165)
    private let cardBg = Color(red: 0.118, green: 0.161, blue: 0.231)
    private let cardStroke = Color(red: 0.200, green: 0.255, blue: 0.333)
    private let primaryBlue = Color(red: 0.008, green: 0.518, blue: 0.780)

    public init(store: MedicationStore, medToEdit: Medication? = nil) {
        self.store = store
        self.medToEdit = medToEdit

        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"

        _nama = State(initialValue: medToEdit?.nama ?? "")
        _dosis = State(initialValue: medToEdit?.dosis ?? "1 Tablet")
        _satuan = State(initialValue: medToEdit?.satuan ?? "Tablet")
        _stokStr = State(initialValue: String(medToEdit?.stok ?? 30))
        _kurangiStr = State(initialValue: String(medToEdit?.kurangiPerMinum ?? 1))
        _aturan = State(initialValue: medToEdit?.aturan ?? "Sesudah Makan")
        _catatan = State(initialValue: medToEdit?.catatan ?? "-")

        _sesiPagiAktif = State(initialValue: medToEdit?.sesiPagiAktif ?? true)
        _jamPagi = State(initialValue: formatter.date(from: medToEdit?.jamPagi ?? "08:00") ?? Date())
        _sesiSiangAktif = State(initialValue: medToEdit?.sesiSiangAktif ?? false)
        _jamSiang = State(initialValue: formatter.date(from: medToEdit?.jamSiang ?? "13:00") ?? Date())
        _sesiSoreAktif = State(initialValue: medToEdit?.sesiSoreAktif ?? false)
        _jamSore = State(initialValue: formatter.date(from: medToEdit?.jamSore ?? "19:00") ?? Date())

        _hariTipe = State(initialValue: medToEdit?.hariTipe ?? "Setiap Hari")
        _selectedHari = State(initialValue: medToEdit?.hariAktif ?? MedicationStore.DAFTAR_HARI)
    }

    public var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Informasi Obat").foregroundColor(.gray)) {
                    TextField("Nama Obat (cth: Paracetamol)", text: $nama)
                    TextField("Dosis (cth: 1 Tablet)", text: $dosis)
                    Picker("Satuan", selection: $satuan) {
                        ForEach(MedicationStore.DAFTAR_SATUAN, id: \.self) { s in
                            Text(s).tag(s)
                        }
                    }
                    HStack {
                        Text("Stok Saat Ini:")
                        Spacer()
                        TextField("30", text: $stokStr)
                            .keyboardType(.numberPad)
                            .multilineTextAlignment(.trailing)
                    }
                    HStack {
                        Text("Pengurangan per Minum:")
                        Spacer()
                        TextField("1", text: $kurangiStr)
                            .keyboardType(.numberPad)
                            .multilineTextAlignment(.trailing)
                    }
                    Picker("Aturan Minum", selection: $aturan) {
                        ForEach(MedicationStore.DAFTAR_ATURAN, id: \.self) { a in
                            Text(a).tag(a)
                        }
                    }
                    TextField("Catatan (opsional)", text: $catatan)
                }

                Section(header: Text("Sesi & Jam Minum").foregroundColor(.gray)) {
                    Toggle("🌅 Sesi Pagi", isOn: $sesiPagiAktif)
                    if sesiPagiAktif {
                        DatePicker("Jam Pagi", selection: $jamPagi, displayedComponents: .hourAndMinute)
                    }

                    Toggle("☀ Sesi Siang", isOn: $sesiSiangAktif)
                    if sesiSiangAktif {
                        DatePicker("Jam Siang", selection: $jamSiang, displayedComponents: .hourAndMinute)
                    }

                    Toggle("🌙 Sesi Sore / Malam", isOn: $sesiSoreAktif)
                    if sesiSoreAktif {
                        DatePicker("Jam Sore", selection: $jamSore, displayedComponents: .hourAndMinute)
                    }
                }

                Section(header: Text("Jadwal Hari").foregroundColor(.gray)) {
                    Picker("Tipe Hari", selection: $hariTipe) {
                        Text("Setiap Hari").tag("Setiap Hari")
                        Text("Pilih Hari Tertentu").tag("Pilih Hari Tertentu")
                    }
                    .pickerStyle(SegmentedPickerStyle())

                    if hariTipe == "Pilih Hari Tertentu" {
                        ForEach(MedicationStore.DAFTAR_HARI, id: \.self) { hari in
                            Button(action: {
                                if selectedHari.contains(hari) {
                                    if selectedHari.count > 1 { selectedHari.removeAll { $0 == hari } }
                                } else {
                                    selectedHari.append(hari)
                                }
                            }) {
                                HStack {
                                    Text(hari).foregroundColor(.white)
                                    Spacer()
                                    if selectedHari.contains(hari) {
                                        Image(systemName: "checkmark").foregroundColor(primaryBlue)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            .navigationBarTitle(medToEdit == nil ? "➕ Tambah Obat" : "✏️ Edit Obat", displayMode: .inline)
            .navigationBarItems(
                leading: Button("Batal") {
                    presentationMode.wrappedValue.dismiss()
                }.foregroundColor(.gray),
                trailing: Button("Simpan") {
                    saveMed()
                }.foregroundColor(primaryBlue).font(.system(size: 16, weight: .bold))
            )
        }
    }

    private func saveMed() {
        guard !nama.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }

        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"

        let jamPagiStr = formatter.string(from: jamPagi)
        let jamSiangStr = formatter.string(from: jamSiang)
        let jamSoreStr = formatter.string(from: jamSore)

        var newMed = medToEdit ?? Medication()
        newMed.nama = nama.trimmingCharacters(in: .whitespacesAndNewlines)
        newMed.dosis = dosis
        newMed.satuan = satuan
        newMed.stok = Int(stokStr) ?? 30
        newMed.kurangiPerMinum = Int(kurangiStr) ?? 1
        newMed.aturan = aturan
        newMed.catatan = catatan

        newMed.sesiPagiAktif = sesiPagiAktif
        newMed.jamPagi = jamPagiStr
        newMed.sesiSiangAktif = sesiSiangAktif
        newMed.jamSiang = jamSiangStr
        newMed.sesiSoreAktif = sesiSoreAktif
        newMed.jamSore = jamSoreStr

        // Jam representasi utama
        if sesiPagiAktif { newMed.jam = jamPagiStr }
        else if sesiSiangAktif { newMed.jam = jamSiangStr }
        else if sesiSoreAktif { newMed.jam = jamSoreStr }

        newMed.hariTipe = hariTipe
        newMed.hariAktif = hariTipe == "Setiap Hari" ? MedicationStore.DAFTAR_HARI : selectedHari

        store.addOrUpdateMedication(newMed)
        presentationMode.wrappedValue.dismiss()
    }
}
