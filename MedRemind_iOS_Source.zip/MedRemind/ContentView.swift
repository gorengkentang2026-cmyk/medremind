import SwiftUI

public struct ContentView: View {
    @StateObject private var store = MedicationStore()

    @State private var selectedTab: Int = 0 // 0 = Jadwal Hari Ini, 1 = Semua Obat
    @State private var currentTimeStr: String = "--:--"
    @State private var greetingStr: String = "Selamat Datang 🌅"

    @State private var showAddEditSheet: Bool = false
    @State private var medToEdit: Medication? = nil
    @State private var showGoogleSheet: Bool = false
    @State private var showUserSheet: Bool = false
    @State private var showHistorySheet: Bool = false

    private let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    private let bgDark = Color(red: 0.059, green: 0.090, blue: 0.165)
    private let cardBg = Color(red: 0.118, green: 0.161, blue: 0.231)
    private let cardStroke = Color(red: 0.200, green: 0.255, blue: 0.333)
    private let primaryBlue = Color(red: 0.008, green: 0.518, blue: 0.780)
    private let accentCyan = Color(red: 0.220, green: 0.741, blue: 0.973)
    private let successGreen = Color(red: 0.063, green: 0.725, blue: 0.506)
    private let dangerRed = Color(red: 0.937, green: 0.267, blue: 0.267)
    private let warningOrange = Color(red: 0.961, green: 0.620, blue: 0.043)
    private let googleBlue = Color(red: 0.259, green: 0.522, blue: 0.957)

    public init() {}

    public var body: some View {
        ZStack(alignment: .bottomTrailing) {
            ScrollView {
                VStack(spacing: 12) {
                    // MARK: - Header
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("MedRemind Pro")
                                .font(.system(size: 20, weight: .bold))
                                .foregroundColor(.white)
                            Text("✨ RELEASE BY ROLLY • iOS")
                                .font(.system(size: 10, weight: .bold))
                                .foregroundColor(accentCyan)
                        }
                        Spacer()

                        // Tombol Sambungkan Google
                        Button(action: { showGoogleSheet = true }) {
                            Text(store.googleAccount.isConnected ? "G✓" : "🌐")
                                .font(.system(size: 13, weight: .bold))
                                .frame(width: 36, height: 32)
                                .foregroundColor(store.googleAccount.isConnected ? successGreen : googleBlue)
                                .background(cardBg)
                                .cornerRadius(8)
                                .overlay(RoundedRectangle(cornerRadius: 8).stroke(store.googleAccount.isConnected ? successGreen : googleBlue, lineWidth: 1))
                        }

                        // Tombol Riwayat
                        Button(action: { showHistorySheet = true }) {
                            Text("📋")
                                .font(.system(size: 13))
                                .frame(width: 36, height: 32)
                                .background(cardBg)
                                .cornerRadius(8)
                                .overlay(RoundedRectangle(cornerRadius: 8).stroke(cardStroke, lineWidth: 1))
                        }

                        // Tombol Tes Notifikasi Alarm
                        Button(action: {
                            NotificationManager.shared.scheduleDose(
                                id: "test_ios_alarm",
                                namaObat: "Uji Coba Alarm iOS",
                                dosis: "1 Tablet",
                                aturan: "Sesudah Makan",
                                sesiNama: "Tes",
                                jamStr: DateFormatter.localizedString(from: Date().addingTimeInterval(3), dateStyle: .none, timeStyle: .short)
                            )
                        }) {
                            Text("🔔")
                                .font(.system(size: 13))
                                .frame(width: 36, height: 32)
                                .background(cardBg)
                                .cornerRadius(8)
                                .overlay(RoundedRectangle(cornerRadius: 8).stroke(warningOrange, lineWidth: 1))
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 8)

                    // MARK: - Baris Profil & Google Status
                    HStack {
                        Text("👤 Profil:")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(.gray)

                        Picker("Profil", selection: $store.activeUserId) {
                            Text("Semua Profil").tag(0)
                            ForEach(store.users) { u in
                                Text("\(u.nama) (\(u.hubungan))").tag(u.id)
                            }
                        }
                        .pickerStyle(MenuPickerStyle())
                        .accentColor(accentCyan)

                        Button(action: { showUserSheet = true }) {
                            Text("➕ Kelola")
                                .font(.system(size: 11, weight: .bold))
                                .foregroundColor(primaryBlue)
                        }

                        Spacer()

                        Button(action: { showGoogleSheet = true }) {
                            if store.googleAccount.isConnected {
                                Text("✅ \(store.googleAccount.email.components(separatedBy: "@").first ?? "")")
                                    .font(.system(size: 11, weight: .bold))
                                    .foregroundColor(successGreen)
                            } else {
                                Text("🌐 Google")
                                    .font(.system(size: 11, weight: .bold))
                                    .foregroundColor(googleBlue)
                            }
                        }
                    }
                    .padding(.horizontal, 16)

                    // MARK: - Baris Jam Digital & Salam
                    HStack {
                        Text(greetingStr)
                            .font(.system(size: 15, weight: .bold))
                            .foregroundColor(.white)
                        Spacer()
                        Text(currentTimeStr)
                            .font(.system(size: 20, weight: .bold, design: .monospaced))
                            .foregroundColor(accentCyan)
                    }
                    .padding(14)
                    .background(cardBg)
                    .cornerRadius(12)
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(cardStroke, lineWidth: 1))
                    .padding(.horizontal, 16)

                    // MARK: - 4 Kartu Statistik Metrik
                    let metrics = store.getMetrics()
                    HStack(spacing: 8) {
                        metricCard(title: "Total\nObat", value: "\(metrics.totalObat)", color: primaryBlue)
                        metricCard(title: "Sudah\nMinum", value: "\(metrics.sudahDiminum)", color: successGreen)
                        metricCard(title: "Sesi\nMenunggu", value: "\(metrics.menunggu)", color: warningOrange)
                        metricCard(title: "Stok\nMenipis", value: "\(metrics.stokMenipis)", color: dangerRed)
                    }
                    .padding(.horizontal, 16)

                    // MARK: - Banner Jadwal Berikutnya
                    HStack {
                        Text("⏰ Jadwal Berikut: \(store.getNextScheduleInfo())")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(.white)
                        Spacer()
                    }
                    .padding(10)
                    .background(cardBg)
                    .cornerRadius(8)
                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(cardStroke, lineWidth: 1))
                    .padding(.horizontal, 16)

                    // MARK: - Segmented Tab
                    Picker("Mode Tampilan", selection: $selectedTab) {
                        Text("Jadwal Hari Ini").tag(0)
                        Text("Semua Obat").tag(1)
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .padding(.horizontal, 16)

                    // MARK: - Konten Daftar
                    if selectedTab == 0 {
                        todayScheduleSection
                    } else {
                        allMedicationsSection
                    }

                    Spacer().frame(height: 80)
                }
            }

            // MARK: - Floating Action Button ➕
            Button(action: {
                medToEdit = nil
                showAddEditSheet = true
            }) {
                HStack {
                    Image(systemName: "plus")
                    Text("Tambah Obat")
                        .font(.system(size: 14, weight: .bold))
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(primaryBlue)
                .foregroundColor(.white)
                .cornerRadius(24)
                .shadow(color: .black.opacity(0.4), radius: 6, x: 0, y: 3)
            }
            .padding(.trailing, 20)
            .padding(.bottom, 20)
        }
        .background(bgDark.edgesIgnoringSafeArea(.all))
        .onReceive(timer) { _ in
            updateClockAndGreeting()
        }
        .onAppear {
            updateClockAndGreeting()
        }
        .sheet(isPresented: $showAddEditSheet) {
            AddEditMedicationView(store: store, medToEdit: medToEdit)
        }
        .sheet(isPresented: $showGoogleSheet) {
            GoogleAccountView(store: store)
        }
        .sheet(isPresented: $showUserSheet) {
            UserProfileView(store: store)
        }
        .sheet(isPresented: $showHistorySheet) {
            HistoryView(store: store)
        }
    }

    // MARK: - Kartu Metrik Helper
    private func metricCard(title: String, value: String, color: Color) -> some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(color)
            Text(title)
                .font(.system(size: 10))
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .frame(height: 64)
        .background(cardBg)
        .cornerRadius(10)
        .overlay(RoundedRectangle(cornerRadius: 10).stroke(cardStroke, lineWidth: 1))
    }

    // MARK: - Tab: Jadwal Hari Ini
    private var todayScheduleSection: some View {
        let schedule = store.getTodaySchedule()
        return VStack(spacing: 8) {
            if schedule.isEmpty {
                VStack(spacing: 8) {
                    Text("💊").font(.system(size: 36))
                    Text("Tidak ada jadwal minum obat untuk hari ini (\(store.getHariIni())).")
                        .font(.system(size: 13))
                        .foregroundColor(.gray)
                }
                .padding(.top, 40)
            } else {
                ForEach(schedule) { item in
                    HStack(spacing: 12) {
                        VStack(alignment: .leading, spacing: 2) {
                            HStack {
                                Text(item.med.nama)
                                    .font(.system(size: 15, weight: .bold))
                                    .foregroundColor(.white)
                                Text(item.sesiNama)
                                    .font(.system(size: 11, weight: .bold))
                                    .foregroundColor(accentCyan)
                            }
                            Text("🕒 \(item.jam) WIB • \(item.med.dosis) (\(item.med.aturan))")
                                .font(.system(size: 12))
                                .foregroundColor(.gray)
                            HStack {
                                Text("Sisa Stok: \(item.med.stok) \(item.med.satuan)")
                                    .font(.system(size: 11, weight: .semibold))
                                    .foregroundColor(item.med.stok <= 5 ? dangerRed : .gray)
                                if item.med.stok <= 5 {
                                    Text("⚠️ Menipis")
                                        .font(.system(size: 10, weight: .bold))
                                        .foregroundColor(dangerRed)
                                }
                            }
                        }
                        Spacer()

                        if item.isDone {
                            Text("✔ Sudah")
                                .font(.system(size: 12, weight: .bold))
                                .padding(.horizontal, 12)
                                .padding(.vertical, 8)
                                .background(successGreen.opacity(0.2))
                                .foregroundColor(successGreen)
                                .cornerRadius(8)
                        } else {
                            Button(action: {
                                store.markTaken(medId: item.med.id, sesiKey: item.sesiKey, sesiNama: item.sesiNama)
                            }) {
                                Text("✔ Minum")
                                    .font(.system(size: 12, weight: .bold))
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 8)
                                    .background(successGreen)
                                    .foregroundColor(.white)
                                    .cornerRadius(8)
                            }
                        }
                    }
                    .padding(12)
                    .background(cardBg)
                    .cornerRadius(10)
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(cardStroke, lineWidth: 1))
                }
            }
        }
        .padding(.horizontal, 16)
    }

    // MARK: - Tab: Semua Obat
    private var allMedicationsSection: some View {
        let meds = store.getMedicationsForActiveUser()
        return VStack(spacing: 8) {
            if meds.isEmpty {
                VStack(spacing: 8) {
                    Text("📦").font(.system(size: 36))
                    Text("Belum ada daftar obat tersimpan.\nTekan tombol ➕ Tambah Obat di bawah.")
                        .font(.system(size: 13))
                        .foregroundColor(.gray)
                        .multilineTextAlignment(.center)
                }
                .padding(.top, 40)
            } else {
                ForEach(meds) { med in
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(med.nama)
                                    .font(.system(size: 15, weight: .bold))
                                    .foregroundColor(.white)
                                Text("\(med.dosis) • \(med.aturan) • \(med.hariTipe)")
                                    .font(.system(size: 12))
                                    .foregroundColor(.gray)
                            }
                            Spacer()
                            Text("Stok: \(med.stok) \(med.satuan)")
                                .font(.system(size: 12, weight: .bold))
                                .foregroundColor(med.stok <= 5 ? dangerRed : successGreen)
                        }

                        HStack(spacing: 8) {
                            Button(action: {
                                store.restock(id: med.id, amount: 10)
                            }) {
                                Text("📦 +10 Stok")
                                    .font(.system(size: 11, weight: .semibold))
                                    .padding(.horizontal, 10)
                                    .padding(.vertical, 6)
                                    .background(primaryBlue.opacity(0.2))
                                    .foregroundColor(accentCyan)
                                    .cornerRadius(6)
                            }

                            Button(action: {
                                medToEdit = med
                                showAddEditSheet = true
                            }) {
                                Text("✏️ Edit")
                                    .font(.system(size: 11, weight: .semibold))
                                    .padding(.horizontal, 10)
                                    .padding(.vertical, 6)
                                    .background(cardStroke)
                                    .foregroundColor(.white)
                                    .cornerRadius(6)
                            }

                            Spacer()

                            Button(action: {
                                store.deleteMedication(id: med.id)
                            }) {
                                Text("🗑")
                                    .font(.system(size: 12))
                                    .foregroundColor(dangerRed)
                                    .padding(.horizontal, 6)
                            }
                        }
                    }
                    .padding(12)
                    .background(cardBg)
                    .cornerRadius(10)
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(cardStroke, lineWidth: 1))
                }
            }
        }
        .padding(.horizontal, 16)
    }

    private func updateClockAndGreeting() {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        currentTimeStr = formatter.string(from: Date())

        let hour = Calendar.current.component(.hour, from: Date())
        let activeUser = store.getActiveUser()
        let name = store.activeUserId != 0 ? " \(activeUser.nama)" : ""

        if (4...10).contains(hour) {
            greetingStr = "Selamat Pagi\(name) 🌅"
        } else if (11...14).contains(hour) {
            greetingStr = "Selamat Siang\(name) ☀"
        } else if (15...17).contains(hour) {
            greetingStr = "Selamat Sore\(name) 🌤"
        } else {
            greetingStr = "Selamat Malam\(name) 🌙"
        }
    }
}
